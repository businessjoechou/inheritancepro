/**
 * avs — AI Verification Standard
 * Main package entry point
 *
 * © 2026 ChouLegal 周全法律科技. All rights reserved.
 * Patent Pending — 法律 AI 計算輸出之四階段自動化驗證方法及系統
 * License: CC BY 4.0 (Attribution required: "Uses AVS by ChouLegal")
 *
 * Usage:
 *   import { verify, certificationLevel, generateMarkdownReport, lookupLaw } from .avs.;
 */

export { verify } from './verifier/index.js';
export { certificationLevel, CERT_EMOJI, CERT_DESC } from './verifier/index.js';
export { generateMarkdownReport, generateSummary } from './report-generator/index.js';
export { lookupLaw, sha256 } from './law-registry/fetch-law.js';
export { verifyJudgmentCitation, verifyJudgmentCitations } from './judgment-registry/index.js';
