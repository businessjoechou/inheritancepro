/**
 * 司法院裁判來源驗證。
 *
 * 驗證器只接受 judgment.judicial.gov.tw 官方裁判書頁面，並核對：
 * - 裁判字號
 * - 裁判日期
 * - 指定的原文證據片段
 * - 已驗證快取指紋（離線模式）
 */

import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CACHE_DIR = join(__dirname, '../../judgment-registry-cache');
const OFFICIAL_HOST = 'judgment.judicial.gov.tw';

export async function verifyJudgmentCitations(citations, opts = {}) {
  const items = [];
  const errors = [];
  const warnings = [];

  if (!Array.isArray(citations) || citations.length === 0) {
    return { status: 'SKIPPED', items, errors, warnings, note: '沒有裁判引用' };
  }

  for (let index = 0; index < citations.length; index += 1) {
    const citation = citations[index];
    const structuralErrors = validateCitationStructure(citation, index);
    if (structuralErrors.length) {
      errors.push(...structuralErrors);
      items.push({ case_no: citation?.caseNo ?? null, status: 'INVALID', errors: structuralErrors });
      continue;
    }

    const result = opts.offline
      ? verifyFromCache(citation)
      : await verifyFromOfficialSource(citation, opts);

    items.push(result);
    if (result.status === 'FAIL') errors.push(...result.errors);
    if (result.status === 'WARN') warnings.push(...result.warnings);
  }

  return {
    status: errors.length > 0 ? 'FAIL' : warnings.length > 0 ? 'WARN' : 'PASS',
    items,
    errors,
    warnings,
  };
}

export async function verifyJudgmentCitation(citation, opts = {}) {
  const report = await verifyJudgmentCitations([citation], opts);
  return report.items[0] ?? { status: 'FAIL', errors: ['裁判驗證沒有產生結果'] };
}

function validateCitationStructure(citation, index) {
  const prefix = `judgments[${index}]`;
  const errors = [];

  if (!citation || typeof citation !== 'object') return [`${prefix}: 必須是物件`];
  if (!citation.caseNo || typeof citation.caseNo !== 'string') errors.push(`${prefix}: caseNo 必須是非空字串`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(citation.judgmentDate ?? '')) errors.push(`${prefix}: judgmentDate 必須為 YYYY-MM-DD`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(citation.verifiedAt ?? '')) errors.push(`${prefix}: verifiedAt 必須為 YYYY-MM-DD`);
  if (citation.verifiedAt > new Date().toISOString().slice(0, 10)) errors.push(`${prefix}: verifiedAt 不得晚於今天`);
  if (citation.judgmentDate > citation.verifiedAt) errors.push(`${prefix}: verifiedAt 不得早於 judgmentDate`);
  if (citation.sourceType !== '司法院裁判書原文') errors.push(`${prefix}: sourceType 必須為「司法院裁判書原文」`);
  if (!['confirmed-final', 'unknown', 'not-final'].includes(citation.finality)) {
    errors.push(`${prefix}: finality 必須為 confirmed-final、unknown 或 not-final`);
  }
  if (!isOfficialJudgmentUrl(citation.sourceUrl)) errors.push(`${prefix}: sourceUrl 必須是司法院裁判書官方 HTTPS 網址`);
  if (!Array.isArray(citation.evidence) || citation.evidence.length < 2) {
    errors.push(`${prefix}: evidence 至少需要兩段可在裁判原文核對的文字`);
  } else if (citation.evidence.some(text => typeof text !== 'string' || normalizeText(text).length < 8)) {
    errors.push(`${prefix}: evidence 每段至少需要 8 個有效字元`);
  }

  return errors;
}

async function verifyFromOfficialSource(citation, opts) {
  try {
    const response = await (opts.fetchImpl ?? fetch)(citation.sourceUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AVS-Verifier/1.1; +https://avs.choulegal.com)',
        Accept: 'text/html,application/xhtml+xml',
        'Accept-Language': 'zh-TW,zh;q=0.9',
      },
    });
    if (!response.ok) throw new Error(`司法院 HTTP ${response.status}`);

    const html = await response.text();
    const sourceText = htmlToText(html);
    const sourceCheck = verifySourceText(citation, sourceText);
    if (sourceCheck.errors.length) {
      return { case_no: citation.caseNo, status: 'FAIL', source_url: citation.sourceUrl, errors: sourceCheck.errors };
    }

    const record = {
      case_no: citation.caseNo,
      judgment_date: citation.judgmentDate,
      source_url: citation.sourceUrl,
      source_hash: sha256(normalizeText(sourceText)),
      citation_fingerprint: citationFingerprint(citation),
      evidence_count: citation.evidence.length,
      verified_at: new Date().toISOString(),
    };
    const warnings = [];
    if (citation.finality === 'unknown') {
      warnings.push(`${citation.caseNo}：尚未確認是否有後續上訴或改判，只能作為該審裁判參考`);
    }
    if (citation.finality === 'not-final') {
      warnings.push(`${citation.caseNo}：已標示為非終局裁判，不得作為確定法律結論`);
    }
    if (citation.finality === 'confirmed-final' && !normalizeText(sourceText).includes('不得上訴')) {
      return {
        case_no: citation.caseNo,
        status: 'FAIL',
        source_url: citation.sourceUrl,
        errors: [`${citation.caseNo}：宣告為確定裁判，但官方原文未見「不得上訴」`],
      };
    }
    writeCache(record);

    return {
      case_no: citation.caseNo,
      status: warnings.length ? 'WARN' : 'PASS',
      source_url: citation.sourceUrl,
      source_hash: record.source_hash,
      evidence_verified: citation.evidence.length,
      from_cache: false,
      warnings,
    };
  } catch (error) {
    const cached = verifyFromCache(citation);
    if (cached.status === 'PASS' || cached.status === 'WARN') {
      return {
        ...cached,
        status: 'WARN',
        warnings: [
          ...(cached.warnings ?? []),
          `${citation.caseNo}：官方來源暫時無法連線，改用先前驗證快取`,
        ],
      };
    }
    return {
      case_no: citation.caseNo,
      status: 'FAIL',
      source_url: citation.sourceUrl,
      errors: [`${citation.caseNo}：無法驗證司法院原文（${error.message}）`],
    };
  }
}

function verifyFromCache(citation) {
  const cacheFile = cachePath(citation.sourceUrl);
  if (!existsSync(cacheFile)) {
    return {
      case_no: citation.caseNo,
      status: 'FAIL',
      source_url: citation.sourceUrl,
      errors: [`${citation.caseNo}：離線模式找不到已驗證裁判快取`],
    };
  }

  const cached = JSON.parse(readFileSync(cacheFile, 'utf8'));
  if (cached.citation_fingerprint !== citationFingerprint(citation)) {
    return {
      case_no: citation.caseNo,
      status: 'FAIL',
      source_url: citation.sourceUrl,
      errors: [`${citation.caseNo}：裁判資料已變更，與官方驗證快取不一致`],
    };
  }

  return {
    case_no: citation.caseNo,
    status: citation.finality === 'confirmed-final' ? 'PASS' : 'WARN',
    source_url: citation.sourceUrl,
    source_hash: cached.source_hash,
    evidence_verified: cached.evidence_count,
    verified_at: cached.verified_at,
    from_cache: true,
    warnings: citation.finality === 'unknown'
      ? [`${citation.caseNo}：尚未確認是否有後續上訴或改判，只能作為該審裁判參考`]
      : citation.finality === 'not-final'
        ? [`${citation.caseNo}：已標示為非終局裁判，不得作為確定法律結論`]
        : [],
  };
}

function verifySourceText(citation, sourceText) {
  const normalizedSource = normalizeText(sourceText);
  const errors = [];
  const normalizedCaseNo = normalizeText(citation.caseNo);

  if (!normalizedSource.includes(normalizedCaseNo)) {
    errors.push(`${citation.caseNo}：官方頁面找不到相同裁判字號`);
  }

  const rocDate = toRocDate(citation.judgmentDate);
  if (!normalizedSource.includes(normalizeText(rocDate))) {
    errors.push(`${citation.caseNo}：官方裁判日期與 judgmentDate 不一致`);
  }

  for (const evidence of citation.evidence) {
    if (!normalizedSource.includes(normalizeText(evidence))) {
      errors.push(`${citation.caseNo}：官方原文找不到證據片段「${evidence}」`);
    }
  }

  return { errors };
}

function isOfficialJudgmentUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' &&
      url.hostname === OFFICIAL_HOST &&
      url.pathname.toLowerCase() === '/fjud/data.aspx' &&
      url.searchParams.get('ty') === 'JD' &&
      Boolean(url.searchParams.get('id'));
  } catch {
    return false;
  }
}

function htmlToText(html) {
  return decodeEntities(String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' '));
}

function decodeEntities(text) {
  return text
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

function normalizeText(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .replace(/[臺台]/g, '臺')
    .replace(/\s+/g, '')
    .replace(/[,，。；：、（）()「」『』]/g, '');
}

function toRocDate(isoDate) {
  const [year, month, day] = isoDate.split('-').map(Number);
  return `民國${year - 1911}年${String(month).padStart(2, '0')}月${String(day).padStart(2, '0')}日`;
}

function citationFingerprint(citation) {
  return sha256(JSON.stringify({
    caseNo: citation.caseNo,
    judgmentDate: citation.judgmentDate,
    verifiedAt: citation.verifiedAt,
    sourceUrl: citation.sourceUrl,
    sourceType: citation.sourceType,
    finality: citation.finality,
    evidence: citation.evidence,
  }));
}

function cachePath(sourceUrl) {
  return join(CACHE_DIR, `${sha256(sourceUrl)}.json`);
}

function writeCache(record) {
  if (!existsSync(CACHE_DIR)) mkdirSync(CACHE_DIR, { recursive: true });
  writeFileSync(cachePath(record.source_url), JSON.stringify(record, null, 2), 'utf8');
}

function sha256(value) {
  return createHash('sha256').update(value, 'utf8').digest('hex');
}

export { isOfficialJudgmentUrl, normalizeText, verifySourceText };
