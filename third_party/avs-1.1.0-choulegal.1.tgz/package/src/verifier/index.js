/**
 * verifier/index.js — AVS 獨立驗證器
 *
 * © 2026 ChouLegal 周全法律科技. All rights reserved.
 * Patent Pending — AI 計算輸出之四階段自動化驗證方法及系統
 *
 * 授權條款：本驗證器原始碼依 CC BY 4.0 授權公開。
 * 商業使用請署名：Uses AVS — AI Verification Standard by ChouLegal
 *
 * 設計原則：
 *  - 不依賴 AI API，純確定性邏輯
 *  - 任何第三方可獨立架設並運行
 *  - 接收 trace JSON，輸出 PASS / FAIL / WARN + 詳細報告
 *
 * 四階段驗證（專利申請中）：
 *  Phase 1: 結構驗證 (Schema Validation)
 *  Phase 2: 法源查核 (Law Source Verification) — SHA-256 哈希比對
 *  Phase 3: 計算重現 (Step Re-computation)
 *  Phase 4: Oracle 比對 (Oracle Matching) — 場景識別碼查找
 *
 * 認證等級輸出：
 *  Bronze   — Phase 1 通過（格式符合）
 *  Silver   — Phase 1-2 通過（法源可驗證）
 *  Gold     — Phase 1-3 通過（計算可重現）
 *  Platinum — Phase 1-4 通過，法源哈希全符（人工案例比對通過）
 */

import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { lookupLaw, sha256 } from '../law-registry/fetch-law.js';
import { verifyJudgmentCitations } from '../judgment-registry/index.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ORACLE_DIR = join(__dirname, '../../test-oracles');
const REQUIRED_FIELDS = ['avs_version', 'function', 'domain', 'input', 'laws', 'steps', 'output', 'confidence', 'law_snapshot_date', 'generated_at'];

/**
 * 主入口：驗證一份 trace JSON
 * @param {object} trace — AVS trace 物件
 * @param {object} [opts]
 * @param {boolean} [opts.skipLawFetch=false] 跳過線上法源查核（離線模式）
 * @param {boolean} [opts.skipOracle=false] 跳過 oracle 比對
 * @returns {Promise<VerificationReport>}
 */
export async function verify(trace, opts = {}) {
  const report = {
    avs_version: '1.0',
    verified_at: new Date().toISOString(),
    trace_function: trace?.function ?? 'unknown',
    confidence: trace?.confidence ?? null,
    overall: 'PASS',
    phases: {},
    warnings: [],
    errors: [],
  };

  // Phase 1
  const phase1 = verifySchema(trace);
  report.phases.schema = phase1;
  if (phase1.status === 'FAIL') {
    report.overall = 'FAIL';
    report.errors.push(...phase1.errors);
    return finalize(report);
  }

  // Phase 2
  if (!opts.skipLawVerification) {
    const phase2 = await verifyLawSource(trace, {
      offline: opts.skipLawFetch ?? opts.offline ?? false,
    });
    report.phases.law_source = phase2;
    if (phase2.status === 'FAIL') {
      report.overall = 'FAIL';
      report.errors.push(...phase2.errors);
    } else if (phase2.status === 'WARN') {
      if (report.overall !== 'FAIL') report.overall = 'WARN';
      report.warnings.push(...phase2.warnings);
    }
  } else {
    report.phases.law_source = { status: 'SKIPPED', note: '離線模式，跳過法源查核' };
  }

  // Phase 2B
  const judgmentCoverage = verifyJudgmentCoverage(trace);
  if (judgmentCoverage.status === 'FAIL') {
    report.phases.judgment_source = judgmentCoverage;
    report.overall = 'FAIL';
    report.errors.push(...judgmentCoverage.errors);
  } else if (Array.isArray(trace.judgments) && trace.judgments.length > 0) {
    const phase2b = await verifyJudgmentCitations(trace.judgments, {
      offline: opts.skipJudgmentFetch ?? opts.skipLawFetch ?? false,
    });
    report.phases.judgment_source = phase2b;
    if (phase2b.status === 'FAIL') {
      report.overall = 'FAIL';
      report.errors.push(...phase2b.errors);
    } else if (phase2b.status === 'WARN') {
      if (report.overall !== 'FAIL') report.overall = 'WARN';
      report.warnings.push(...phase2b.warnings);
    }
  } else {
    report.phases.judgment_source = {
      status: 'SKIPPED',
      note: 'trace 未引用裁判，略過裁判來源查核',
    };
  }

  // Phase 3
  const phase3 = verifyComputation(trace);
  report.phases.computation = phase3;
  if (phase3.status === 'FAIL') {
    report.overall = 'FAIL';
    report.errors.push(...phase3.errors);
  } else if (phase3.status === 'WARN') {
    if (report.overall !== 'FAIL') report.overall = 'WARN';
    report.warnings.push(...phase3.warnings);
  }

  // Phase 4
  if (!opts.skipOracle) {
    const phase4 = verifyOracle(trace);
    report.phases.oracle = phase4;
    if (phase4.status === 'FAIL') {
      report.overall = 'FAIL';
      report.errors.push(...phase4.errors);
    }
  } else {
    report.phases.oracle = { status: 'SKIPPED', note: '已略過 oracle 比對' };
  }

  return finalize(report);
}

// ─── 認證等級 ─────────────────────────────────────────────────────────────────
/**
 * 依通過階段深度輸出認證等級（Patent Pending）
 * Bronze < Silver < Gold < Platinum
 */
export function certificationLevel(report) {
  if (report.overall === 'FAIL') return 'None';

  const p = report.phases;

  const p1ok = p.schema?.status === 'PASS';
  const p2ok = p.law_source?.status === 'PASS';
  const p2warn = p.law_source?.status === 'WARN';
  const judgmentOk = p.judgment_source?.status === 'PASS' || p.judgment_source?.status === 'SKIPPED';
  const p3ok = p.computation?.status === 'PASS' &&
    p.computation?.steps_checked > 0 &&
    p.computation?.steps_unchecked === 0;
  const p4ok = p.oracle?.status === 'PASS' && p.oracle?.oracle_tested === true;
  const confidence = report.confidence;
  const automaticallyVerifiable = confidence === 'deterministic' || confidence === 'rule-based';
  const allSourcesVerified = !p2warn && p2ok && judgmentOk;

  if (automaticallyVerifiable && p1ok && allSourcesVerified && p3ok && p4ok) return 'Platinum';
  if (automaticallyVerifiable && p1ok && p2ok && judgmentOk && p3ok)         return 'Gold';
  if (p1ok && (p2ok || p2warn))            return 'Silver';
  if (p1ok)                                return 'Bronze';
  return 'None';
}

const CERT_EMOJI = { Platinum: '💎', Gold: '🥇', Silver: '🥈', Bronze: '🥉', None: '✗' };
const CERT_DESC = {
  Platinum: '人工確認標準案例比對通過，法源哈希全符',
  Gold:     '計算步驟可完整重現',
  Silver:   '法源存在性已核驗',
  Bronze:   '推理軌跡格式符合 AVS 標準',
  None:     '未通過基本格式驗證',
};
export { CERT_EMOJI, CERT_DESC };

// ─── Phase 1: 結構驗證 ──────────────────────────────────────────────────────

function verifySchema(trace) {
  const errors = [];

  if (!trace || typeof trace !== 'object') {
    return { status: 'FAIL', errors: ['trace 不是有效的物件'] };
  }

  if (trace.function !== undefined && (typeof trace.function !== 'string' || !trace.function.trim())) {
    errors.push('function 必須是非空字串');
  }

  if (trace.input !== undefined && (!trace.input || typeof trace.input !== 'object' || Array.isArray(trace.input))) {
    errors.push('input 必須是物件');
  }

  for (const field of REQUIRED_FIELDS) {
    if (!(field in trace)) {
      errors.push(`缺少必要欄位: ${field}`);
    }
  }

  if (trace.avs_version && trace.avs_version !== '1.0') {
    errors.push(`不支援的 avs_version: ${trace.avs_version}（目前只支援 1.0）`);
  }

  if (!Array.isArray(trace.laws) || trace.laws.length === 0) {
    errors.push('laws 必須是非空陣列');
  }

  if (!Array.isArray(trace.steps) || trace.steps.length === 0) {
    errors.push('steps 必須是非空陣列');
  }

  const validDomains = ['labor', 'civil', 'consumer', 'rental', 'inheritance', 'criminal', 'tax', 'medical', 'finance', 'engineering', 'insurance', 'environmental'];
  if (trace.domain && !validDomains.includes(trace.domain)) {
    errors.push(`未知的 domain: ${trace.domain}`);
  }

  const validConfidence = ['deterministic', 'rule-based', 'interpretive', 'unverifiable'];
  if (trace.confidence && !validConfidence.includes(trace.confidence)) {
    errors.push(`未知的 confidence: ${trace.confidence}`);
  }

  if (trace.laws) {
    trace.laws.forEach((law, i) => {
      if (!law.article) errors.push(`laws[${i}] 缺少 article 欄位`);
    });
  }

  if (trace.steps) {
    trace.steps.forEach((step, i) => {
      if (!step.label) errors.push(`steps[${i}] 缺少 label 欄位`);
      if (!('value' in step)) errors.push(`steps[${i}] 缺少 value 欄位`);
    });
  }

  if (trace.judgments !== undefined && !Array.isArray(trace.judgments)) {
    errors.push('judgments 必須是陣列');
  }

  return errors.length === 0
    ? { status: 'PASS', fields_checked: REQUIRED_FIELDS.length }
    : { status: 'FAIL', errors };
}

function verifyJudgmentCoverage(trace) {
  const detected = collectCaseNumbers(trace);
  if (detected.length === 0) return { status: 'PASS', detected_case_numbers: [] };

  const declared = Array.isArray(trace.judgments) ? trace.judgments : [];
  const missing = detected.filter(caseNo => (
    !declared.some(citation => normalizeCaseNumber(citation?.caseNo).includes(normalizeCaseNumber(caseNo)))
  ));

  if (missing.length > 0) {
    return {
      status: 'FAIL',
      detected_case_numbers: detected,
      errors: missing.map(caseNo => `偵測到未申報裁判案號：${caseNo}；必須列入 judgments 並通過司法院原文驗證`),
    };
  }

  return { status: 'PASS', detected_case_numbers: detected };
}

function collectCaseNumbers(value, key = '') {
  if (key === 'judgments') return [];
  if (typeof value === 'string') {
    return value.match(/\d{2,3}\s*年度?\s*[\p{Script=Han}A-Za-z0-9-]{1,12}字第\s*\d+\s*號/gu) ?? [];
  }
  if (Array.isArray(value)) return [...new Set(value.flatMap(item => collectCaseNumbers(item)))];
  if (value && typeof value === 'object') {
    return [...new Set(Object.entries(value).flatMap(([childKey, child]) => collectCaseNumbers(child, childKey)))];
  }
  return [];
}

function normalizeCaseNumber(value) {
  return String(value ?? '').normalize('NFKC').replace(/\s+/g, '');
}

// ─── Phase 2: 法源查核 ──────────────────────────────────────────────────────

async function verifyLawSource(trace, opts = {}) {
  const items = [];
  const errors = [];
  const warnings = [];

  for (const law of trace.laws) {
    const result = await lookupLaw(law.article, { offline: opts.offline });

    if (result.error) {
      items.push({ article: law.article, status: 'NOT_FOUND', error: result.error });
      errors.push(`法條不存在：${law.article} — ${result.error}`);
      continue;
    }

    const item = {
      article: law.article,
      source_url: result.source_url,
      fetched_at: result.fetched_at,
      from_cache: result.from_cache,
    };

    if (law.pcode && law.pcode !== result.pcode) {
      item.status = 'PCODE_MISMATCH';
      errors.push(`pcode 不符：${law.article} 宣告 ${law.pcode}，官方登記為 ${result.pcode}`);
    }
    if (law.article_number && law.article_number !== result.flno) {
      item.status = 'ARTICLE_NUMBER_MISMATCH';
      errors.push(`條號不符：${law.article} 宣告 ${law.article_number}，官方登記為 ${result.flno}`);
    }
    if (law.source_url) {
      try {
        const sourceUrl = new URL(law.source_url);
        if (sourceUrl.protocol !== 'https:' || sourceUrl.hostname !== 'law.moj.gov.tw') {
          item.status = 'SOURCE_URL_INVALID';
          errors.push(`法源網址不是全國法規資料庫官方 HTTPS 網址：${law.article}`);
        }
      } catch {
        item.status = 'SOURCE_URL_INVALID';
        errors.push(`法源網址格式錯誤：${law.article}`);
      }
    }

    if (law.source_hash) {
      if (result.hash === law.source_hash) {
        if (!item.status) item.status = 'VERIFIED';
        item.hash_match = true;
      } else {
        item.status = 'HASH_MISMATCH';
        item.hash_match = false;
        item.trace_hash = law.source_hash;
        item.current_hash = result.hash;
        warnings.push(`法條已更新：${law.article}（trace hash 與當前版本不符，請確認修法是否影響計算結果）`);
      }
    } else {
      if (!item.status) item.status = 'FOUND_NO_HASH';
      item.note = 'trace 未提供 source_hash，僅確認法條存在';
      warnings.push(`法條未鎖定版本：${law.article}（缺少 source_hash）`);
    }

    items.push(item);
  }

  const status = errors.length > 0 ? 'FAIL' : warnings.length > 0 ? 'WARN' : 'PASS';
  return { status, items, errors, warnings };
}

// ─── Phase 3: 計算重現 ──────────────────────────────────────────────────────

function verifyComputation(trace) {
  const results = [];
  const errors = [];
  const warnings = [];

  // 建立變數池：從 input 開始
  const vars = { ...trace.input };

  for (let i = 0; i < trace.steps.length; i++) {
    const step = trace.steps[i];
    const expected = step.value;

    // 若 step 有 formula，嘗試重算
    if (step.formula) {
      try {
        const computed = evalFormula(step.formula, vars, step.inputs ?? {});
        const diff = typeof expected === 'number' && typeof computed === 'number'
          ? Math.abs(expected - computed)
          : null;

        const tolerance = step.tolerance ?? 0.01;
        if (diff !== null && diff > tolerance) {
          results.push({ step: step.label, status: 'MISMATCH', expected, computed, diff });
          errors.push(`步驟 "${step.label}" 計算不符：預期 ${expected}，重算得 ${computed}（差 ${diff.toFixed(4)}）`);
        } else {
          results.push({ step: step.label, status: 'PASS', value: expected });
        }
      } catch (e) {
        results.push({ step: step.label, status: 'UNCHECKED', note: `公式無法自動解析: ${e.message}` });
        const message = `步驟 "${step.label}" 無法自動重算：${e.message}`;
        if (trace.confidence === 'deterministic' || trace.confidence === 'rule-based') errors.push(message);
        else warnings.push(message);
      }
    } else {
      results.push({ step: step.label, status: 'UNCHECKED', note: '無 formula，略過重算' });
      const message = `步驟 "${step.label}" 缺少 formula，無法自動重算`;
      if (trace.confidence === 'deterministic' || trace.confidence === 'rule-based') errors.push(message);
      else warnings.push(message);
    }

    // 將此 step 結果存入變數池（供後續 steps 引用）
    if (step.label) vars[`step_${i}`] = step.value;
    if (step.inputs) Object.assign(vars, step.inputs);
  }

  // 驗證最終 output 與最後一步 value 一致
  const lastStep = trace.steps[trace.steps.length - 1];
  if (lastStep && typeof trace.output === 'number' && typeof lastStep.value === 'number') {
    const outputDiff = Math.abs(trace.output - lastStep.value);
    if (outputDiff > 0.01) errors.push(`最終 output（${trace.output}）與最後一步 value（${lastStep.value}）不一致`);
  } else if (lastStep && (trace.confidence === 'deterministic' || trace.confidence === 'rule-based')) {
    const outputMatches = JSON.stringify(trace.output) === JSON.stringify(lastStep.value);
    const outputCoveredBySteps = trace.output && typeof trace.output === 'object' &&
      Object.values(trace.output)
        .filter(value => typeof value === 'number' || typeof value === 'boolean')
        .every(value => trace.steps.some(step => Object.is(step.value, value)));
    if (!outputMatches && !outputCoveredBySteps) {
      errors.push('最終 output 無法由計算步驟完整追溯');
    }
  }

  return {
    status: errors.length > 0 ? 'FAIL' : warnings.length > 0 ? 'WARN' : 'PASS',
    steps_checked: results.filter(r => r.status !== 'UNCHECKED').length,
    steps_unchecked: results.filter(r => r.status === 'UNCHECKED').length,
    steps_failed: errors.length,
    step_results: results,
    errors,
    warnings,
  };
}

/** 簡易公式求值（支援基本四則與 min/max） */
function evalFormula(formula, vars, stepInputs) {
  const allVars = { ...vars, ...stepInputs };

  // 替換變數名稱為數值
  let expr = formula;
  for (const [key, val] of Object.entries(allVars)) {
    if (typeof val === 'number') {
      expr = expr.replace(new RegExp(`\\b${key}\\b`, 'g'), String(val));
    }
  }

  // 替換 × 為 *、÷ 為 /
  expr = expr.replace(/×/g, '*').replace(/÷/g, '/');

  // 替換允許的數學函式
  expr = expr
    .replace(/\bmin\(/g, 'Math.min(')
    .replace(/\bmax\(/g, 'Math.max(')
    .replace(/\bround\(/g, 'Math.round(')
    .replace(/\bfloor\(/g, 'Math.floor(')
    .replace(/\bceil\(/g, 'Math.ceil(');

  // 安全求值（只允許數字、四則、比較、三元運算與白名單 Math 函式）
  if (!/^[\d\s+\-*/.(),<>=!?:Mathminaxroudfceil]+$/.test(expr)) {
    throw new Error(`公式包含不安全字符: ${expr}`);
  }

  // eslint-disable-next-line no-new-func
  return Function(`"use strict"; return (${expr});`)();
}

// ─── Phase 4: Oracle 比對 ───────────────────────────────────────────────────
// 使用 scenario_id 查找 oracle（產品中立）
// 任何 AI 系統在 trace 的 scenario_id 欄位宣告它在回答哪個場景

function verifyOracle(trace) {
  // 若 trace 未宣告 scenario_id，跳過 oracle 比對
  if (!trace.scenario_id) {
    return {
      status: 'PASS',
      note: 'SCENARIO_NOT_DECLARED — trace 未提供 scenario_id，略過 oracle 比對。提供 scenario_id 可啟動人工確認案例驗證。',
      oracle_tested: false,
    };
  }

  // 從所有 oracle 目錄搜尋匹配的 scenario
  const scenario = findScenario(trace.scenario_id, trace.domain);

  if (!scenario) {
    return {
      status: 'FAIL',
      note: `SCENARIO_NOT_FOUND — 找不到 scenario_id="${trace.scenario_id}" 的 oracle 案例`,
      oracle_tested: false,
      errors: [`trace 宣告了不存在的 oracle 場景：${trace.scenario_id}`],
    };
  }

  const errors = [];
  const constraints = scenario.verification_constraints ?? {};

  if (scenario.domain !== trace.domain) {
    errors.push(`Oracle 領域不符：場景為 ${scenario.domain}，trace 為 ${trace.domain}`);
  }

  // 比對主要答案
  const expectedAnswer = scenario.expected_answer;
  if (expectedAnswer) {
    const actual = trace.output;
    const tolerance = constraints.answer_tolerance_twd ?? 1;

    // 數值比對（amount_twd）
    if (expectedAnswer.amount_twd !== undefined) {
      const actualAmt = typeof actual === 'number' ? actual
        : (actual?.amount_twd ?? actual?.amount ?? actual);
      if (typeof actualAmt !== 'number' || !Number.isFinite(actualAmt)) {
        errors.push(`答案缺失：oracle 要求 amount_twd=${expectedAnswer.amount_twd}，實際輸出沒有可比較的數值`);
      } else if (Math.abs(expectedAnswer.amount_twd - actualAmt) > tolerance) {
        errors.push(`答案不符：oracle 預期 ${expectedAnswer.amount_twd} 元，實際 ${actualAmt} 元（誤差超過 ${tolerance} 元）`);
      }
    }

    const genericExpectedEntries = Object.entries(expectedAnswer)
      .filter(([key]) => !['basis', 'amount_twd', 'notice_days'].includes(key));
    for (const [key, expectedValue] of genericExpectedEntries) {
      const actualValue = actual && typeof actual === 'object' ? actual[key] : undefined;
      if (actualValue === undefined) {
        errors.push(`答案缺失：oracle 要求欄位 ${key}=${JSON.stringify(expectedValue)}`);
        continue;
      }
      if (typeof expectedValue === 'number' && typeof actualValue === 'number') {
        const fieldTolerance = key.endsWith('_decimal') ? 0.0001 : tolerance;
        if (Math.abs(expectedValue - actualValue) > fieldTolerance) {
          errors.push(`欄位不符：${key} 預期 ${expectedValue}，實際 ${actualValue}`);
        }
      } else if (expectedValue !== actualValue) {
        errors.push(`欄位不符：${key} 預期 ${JSON.stringify(expectedValue)}，實際 ${JSON.stringify(actualValue)}`);
      }
    }

    // 天數比對（notice_days）
    if (expectedAnswer.notice_days !== undefined && actual?.days !== undefined) {
      if (actual.days !== expectedAnswer.notice_days) {
        errors.push(`預告天數不符：oracle 預期 ${expectedAnswer.notice_days} 日，實際 ${actual.days} 日`);
      }
    }

    // 未預告工資比對
    if (expectedAnswer.amount_twd !== undefined && actual?.amount !== undefined
        && expectedAnswer.notice_days !== undefined) {
      if (Math.abs(actual.amount - expectedAnswer.amount_twd) > tolerance) {
        errors.push(`未預告工資不符：oracle 預期 ${expectedAnswer.amount_twd} 元，實際 ${actual.amount} 元`);
      }
    }
  }

  // 必須引用的法條
  if (constraints.laws_must_cite) {
    const traceArticles = (trace.laws ?? []).map(l => l.article);
    for (const required of constraints.laws_must_cite) {
      if (!traceArticles.includes(required)) {
        errors.push(`未引用必要法條：${required}`);
      }
    }
  }

  // 最少步驟數
  if (constraints.reasoning_steps_min && (trace.steps?.length ?? 0) < constraints.reasoning_steps_min) {
    errors.push(`推理步驟不足：oracle 要求至少 ${constraints.reasoning_steps_min} 步，實際 ${trace.steps?.length ?? 0} 步`);
  }

  // 信心等級
  if (constraints.confidence_required && trace.confidence !== constraints.confidence_required) {
    errors.push(`信心等級不符：oracle 要求 ${constraints.confidence_required}，實際 ${trace.confidence}`);
  }

  return {
    status: errors.length === 0 ? 'PASS' : 'FAIL',
    scenario_id: scenario.scenario_id,
    scenario_title: scenario.title,
    oracle_tested: true,
    expected_answer: scenario.expected_answer,
    actual_output: trace.output,
    errors,
  };
}


/**
 * 從 oracle 庫中用 scenario_id 找到對應場景
 * 掃描所有法域目錄，支援新的 scenario-based 格式（scenarios 陣列）
 */
function findScenario(scenarioId, domain) {
  // 先找指定 domain，找不到再掃全部
  const searchDirs = domain
    ? [join(ORACLE_DIR, domain), ...readdirSync(ORACLE_DIR)
        .filter(d => d !== domain)
        .map(d => join(ORACLE_DIR, d))]
    : readdirSync(ORACLE_DIR).map(d => join(ORACLE_DIR, d));

  for (const dir of searchDirs) {
    if (!existsSync(dir)) continue;
    try {
      const files = readdirSync(dir).filter(f => f.endsWith('.json'));
      for (const file of files) {
        const db = JSON.parse(readFileSync(join(dir, file), 'utf8'));
        // 新格式：scenarios 陣列
        const found = db.scenarios?.find(s => s.scenario_id === scenarioId);
        if (found) return found;
      }
    } catch { /* ignore */ }
  }
  return null;
}

function finalize(report) {
  // 若所有 phase 為 PASS 但有 warning，整體為 WARN
  if (report.overall === 'PASS' && report.warnings.length > 0) {
    report.overall = 'WARN';
  }
  return report;
}
