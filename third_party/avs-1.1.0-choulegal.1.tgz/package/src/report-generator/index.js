/**
 * report-generator/index.js — AVS 稽核報告產生器
 *
 * © 2026 ChouLegal 周全法律科技. All rights reserved.
 * Patent Pending — 法律 AI 計算輸出之四階段自動化驗證方法及系統
 * License: CC BY 4.0
 *
 * 將驗證結果轉換為人可讀的文字報告（Markdown / 純文字）。
 * 未來可擴充 PDF 輸出。
 */

import { certificationLevel, CERT_EMOJI, CERT_DESC } from '../verifier/index.js';

const STATUS_EMOJI = { PASS: '✓', FAIL: '✗', WARN: '△', SKIPPED: '—', UNCHECKED: '?' };
const STATUS_ZH = { PASS: '通過', FAIL: '失敗', WARN: '警告', SKIPPED: '略過', UNCHECKED: '未查核' };

/**
 * 產生 Markdown 格式稽核報告
 * @param {object} report — verify() 的輸出
 * @param {object} [trace] — 原始 trace（選填，用於補充資訊）
 * @returns {string} Markdown 文字
 */
export function generateMarkdownReport(report, trace) {
  const lines = [];
  const overall = report.overall;
  const overallEmoji = overall === 'PASS' ? '✅' : overall === 'FAIL' ? '❌' : '⚠️';

  lines.push(`# AI 輸出驗證稽核報告`);
  lines.push(`**AVS 版本：** ${report.avs_version}`);
  lines.push(`**驗證時間：** ${report.verified_at}`);
  lines.push(`**計算函式：** \`${report.trace_function}\``);
  if (trace?.law_snapshot_date) lines.push(`**法律快照日期：** ${trace.law_snapshot_date}`);
  if (trace?.system?.name) lines.push(`**系統：** ${trace.system.name} ${trace.system.version ?? ''}`);
  lines.push('');
  const cert = certificationLevel(report);
  lines.push(`## 整體結論：${overallEmoji} ${STATUS_ZH[overall] ?? overall}`);
  lines.push('');
  lines.push(`**認證等級：** ${CERT_EMOJI[cert]} ${cert} — ${CERT_DESC[cert]}`);
  lines.push('');
  lines.push(`> © 2026 ChouLegal 周全法律科技. Patent Pending. 本報告由 AVS v1.0 自研自檢系統自動產生。`);
  lines.push('');

  // Phase 1: Schema
  const s = report.phases.schema;
  if (s) {
    lines.push(`### 一、結構驗證 ${STATUS_EMOJI[s.status] ?? ''} ${STATUS_ZH[s.status] ?? s.status}`);
    if (s.fields_checked) lines.push(`- 必要欄位查核：${s.fields_checked} 項`);
    if (s.errors?.length) s.errors.forEach(e => lines.push(`- ❌ ${e}`));
    lines.push('');
  }

  // Phase 2: Law Source
  const l = report.phases.law_source;
  if (l && l.status !== 'SKIPPED') {
    lines.push(`### 二、法源查核 ${STATUS_EMOJI[l.status] ?? ''} ${STATUS_ZH[l.status] ?? l.status}`);
    if (l.items) {
      l.items.forEach(item => {
        const icon = item.status === 'VERIFIED' ? '✓' : item.status === 'HASH_MISMATCH' ? '△' : item.status === 'NOT_FOUND' ? '✗' : '?';
        const detail = item.source_url ? ` ([官方來源](${item.source_url}))` : '';
        const hashNote = item.hash_match === false ? ` ⚠️ 法條已更新` : item.hash_match === true ? ` hash 一致` : '';
        lines.push(`- ${icon} **${item.article}** — ${item.fetched_at ?? '未知日期'}${hashNote}${detail}`);
      });
    }
    if (l.warnings?.length) l.warnings.forEach(w => lines.push(`- ⚠️ ${w}`));
    if (l.errors?.length) l.errors.forEach(e => lines.push(`- ❌ ${e}`));
    lines.push('');
  } else if (l?.status === 'SKIPPED') {
    lines.push(`### 二、法源查核 — 略過（離線模式）`);
    lines.push('');
  }

  const j = report.phases.judgment_source;
  if (j && j.status !== 'SKIPPED') {
    lines.push(`### 二-B、裁判來源查核 ${STATUS_EMOJI[j.status] ?? ''} ${STATUS_ZH[j.status] ?? j.status}`);
    for (const item of j.items ?? []) {
      const source = item.source_url ? ` ([司法院原文](${item.source_url}))` : '';
      lines.push(`- ${STATUS_EMOJI[item.status] ?? '?'} **${item.case_no ?? '未知案號'}** — 證據片段 ${item.evidence_verified ?? 0} 段${source}`);
    }
    j.warnings?.forEach(w => lines.push(`- ⚠️ ${w}`));
    j.errors?.forEach(e => lines.push(`- ❌ ${e}`));
    lines.push('');
  }

  // Phase 3: Computation
  const c = report.phases.computation;
  if (c) {
    lines.push(`### 三、計算步驟驗證 ${STATUS_EMOJI[c.status] ?? ''} ${STATUS_ZH[c.status] ?? c.status}`);
    lines.push(`- 已驗步驟：${c.steps_checked ?? 0} 項`);
    if (c.steps_unchecked) lines.push(`- 未能自動驗證：${c.steps_unchecked} 項（formula 含複雜邏輯）`);
    if (c.steps_failed) lines.push(`- 驗證失敗：${c.steps_failed} 項`);
    if (c.step_results) {
      c.step_results.forEach((r, i) => {
        const icon = STATUS_EMOJI[r.status] ?? '?';
        const detail = r.status === 'MISMATCH'
          ? `預期 ${r.expected}，重算得 ${r.computed}（差 ${r.diff?.toFixed(2)}）`
          : r.status === 'UNCHECKED' ? r.note ?? ''
          : `值 = ${r.value}`;
        lines.push(`  ${i + 1}. ${icon} **${r.step}** — ${detail}`);
      });
    }
    if (c.errors?.length) c.errors.forEach(e => lines.push(`- ❌ ${e}`));
    lines.push('');
  }

  // Phase 4: Oracle
  const o = report.phases.oracle;
  if (o && o.status !== 'SKIPPED') {
    lines.push(`### 四、Oracle 比對 ${STATUS_EMOJI[o.status] ?? ''} ${STATUS_ZH[o.status] ?? o.status}`);
    if (!o.oracle_tested) {
      lines.push(`- ${o.note}`);
    } else {
      lines.push(`- Oracle 案例：\`${o.scenario_id}\` — ${o.scenario_title ?? ''}`);
      lines.push(`- 預期輸出：${JSON.stringify(o.expected_answer)}`);
      lines.push(`- 實際輸出：${JSON.stringify(o.actual_output)}`);
      if (o.errors?.length) o.errors.forEach(e => lines.push(`- ❌ ${e}`));
    }
    lines.push('');
  }

  // Summary
  if (report.warnings.length > 0) {
    lines.push(`### 警告事項`);
    report.warnings.forEach(w => lines.push(`- ⚠️ ${w}`));
    lines.push('');
  }

  if (overall === 'PASS') {
    lines.push(`---`);
    lines.push(`*本報告由 AVS v1.0 自動產生。法源查核連至全國法規資料庫（law.moj.gov.tw）。*`);
    lines.push(`*驗證邏輯完整開源，任何人可獨立執行確認。*`);
  } else if (overall === 'FAIL') {
    lines.push(`---`);
    lines.push(`> ❌ 此輸出驗證**未通過**，請勿直接使用。請排查上述錯誤後重新驗證。`);
  } else {
    lines.push(`---`);
    lines.push(`> ⚠️ 此輸出有警告事項，建議人工複核後再使用（特別是法條更新的情況）。`);
  }

  return lines.join('\n');
}

/**
 * 產生純文字摘要（適合 CLI 輸出）
 */
export function generateSummary(report) {
  const overall = report.overall;
  const icon = overall === 'PASS' ? '✅' : overall === 'FAIL' ? '❌' : '⚠️';
  const lines = [
    `${icon} AVS 驗證結果：${overall}`,
    `   函式：${report.trace_function}`,
    `   時間：${report.verified_at}`,
  ];

  if (report.phases.schema?.status)
    lines.push(`   結構驗證：${report.phases.schema.status}`);
  if (report.phases.law_source?.status)
    lines.push(`   法源查核：${report.phases.law_source.status}（${report.phases.law_source.items?.length ?? 0} 條）`);
  if (report.phases.judgment_source?.status)
    lines.push(`   裁判查核：${report.phases.judgment_source.status}（${report.phases.judgment_source.items?.length ?? 0} 則）`);
  if (report.phases.computation?.status)
    lines.push(`   計算驗證：${report.phases.computation.status}（${report.phases.computation.steps_checked ?? 0} 步通過）`);
  if (report.phases.oracle?.status) {
    const o = report.phases.oracle;
    const oLabel = o.oracle_tested
      ? `✓ ${o.scenario_id}（${o.scenario_title ?? ''}）`
      : (o.note?.startsWith('SCENARIO_NOT_DECLARED') ? '未宣告 scenario_id' : '找不到匹配案例');
    lines.push(`   Oracle：${oLabel}`);
  }
  const cert2 = certificationLevel(report);
  lines.push(`   認證等級：${CERT_EMOJI[cert2]} ${cert2}`);

  if (report.errors.length)
    report.errors.forEach(e => lines.push(`   ✗ ${e}`));
  if (report.warnings.length)
    report.warnings.forEach(w => lines.push(`   △ ${w}`));

  return lines.join('\n');
}
