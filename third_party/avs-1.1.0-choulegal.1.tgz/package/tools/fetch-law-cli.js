#!/usr/bin/env node
/**
 * fetch-law-cli.js — CLI：更新法源登記冊
 *
 * 用法：
 *   node tools/fetch-law-cli.js --article "勞退條例§12"
 *   node tools/fetch-law-cli.js --update-all
 *   node tools/fetch-law-cli.js --update-all --force
 *   node tools/fetch-law-cli.js --list
 */

import { lookupLaw, updateAllLaws, KNOWN_LAWS } from '../src/law-registry/fetch-law.js';

const args = process.argv.slice(2);
const opts = parseArgs(args);

async function main() {
  if (opts.list) {
    console.log('\n已知法條對照表：');
    for (const [article, info] of Object.entries(KNOWN_LAWS)) {
      console.log(`  ${article.padEnd(14)} pcode: ${info.pcode}  條號: ${info.flno}  (${info.name})`);
    }
    console.log(`\n共 ${Object.keys(KNOWN_LAWS).length} 條\n`);
    return;
  }

  if (opts.updateAll) {
    console.log(`\n更新所有法條 (${Object.keys(KNOWN_LAWS).length} 條)...`);
    if (opts.force) console.log('（強制重新抓取，忽略 cache）\n');

    const results = await updateAllLaws({
      forceRefresh: opts.force ?? false,
      onProgress(article, result) {
        if (result.error) {
          console.log(`  ✗ ${article.padEnd(14)} — ${result.error}`);
        } else if (result.from_cache) {
          console.log(`  — ${article.padEnd(14)} — 使用 cache（${result.fetched_at}）`);
        } else {
          console.log(`  ✓ ${article.padEnd(14)} — 已抓取 hash: ${result.hash?.slice(0, 16)}...`);
        }
      }
    });

    const failed = results.filter(r => r.error);
    console.log(`\n完成：${results.length - failed.length} 成功，${failed.length} 失敗`);
    if (failed.length > 0) {
      console.log('失敗項目：');
      failed.forEach(r => console.log(`  - ${r.article}: ${r.error}`));
    }
    return;
  }

  if (opts.article) {
    console.log(`\n查詢：${opts.article}`);
    const result = await lookupLaw(opts.article, { forceRefresh: opts.force ?? false });

    if (result.error) {
      console.log(`❌ ${result.error}`);
      process.exit(1);
    }

    console.log(`✓ ${result.article}`);
    console.log(`  法律名稱：${result.law_name}`);
    console.log(`  pcode：${result.pcode}  條號：${result.flno}`);
    console.log(`  抓取日期：${result.fetched_at}${result.from_cache ? ' (cache)' : ' (新抓)'}`);
    console.log(`  SHA-256：${result.hash}`);
    console.log(`  來源：${result.source_url}`);
    console.log(`  條文摘錄：${result.text?.slice(0, 100)}...`);
    return;
  }

  console.log('用法:');
  console.log('  node tools/fetch-law-cli.js --list');
  console.log('  node tools/fetch-law-cli.js --article "勞退條例§12"');
  console.log('  node tools/fetch-law-cli.js --update-all [--force]');
}

function parseArgs(args) {
  const result = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--article') result.article = args[++i];
    else if (args[i] === '--update-all') result.updateAll = true;
    else if (args[i] === '--force') result.force = true;
    else if (args[i] === '--list') result.list = true;
  }
  return result;
}

main().catch(e => {
  console.error('失敗：', e.message);
  process.exit(1);
});
