#!/usr/bin/env node
/**
 * stress-test.js — 50 次隨機壓力驗證
 * 測試新制資遣費 / 舊制資遣費 / 預告工資 / 加班費 四類計算
 * 每筆：Phase 1 結構 + Phase 2 法源 + Phase 3 計算重現
 * 統計：通過率 / 平均時間 / 分類明細
 */

import { verify } from '../src/verifier/index.js';

// ── 50 組測試案例定義 ────────────────────────────────────────────────────────

function makeSeveranceNewTrace(totalMonths, avgWage) {
  const years = totalMonths / 12;
  const rawBasis = years * 0.5;
  const basis = Math.min(rawBasis, 6);
  const result = Math.round(basis * avgWage);
  const steps = [
    { label: '服務年資換算', formula: `${totalMonths} / 12`, value: years },
    { label: '基數計算', formula: `${years} × 0.5`, value: rawBasis },
  ];
  if (rawBasis > 6) steps.push({ label: '上限套用', formula: `min(${rawBasis}, 6)`, value: 6 });
  steps.push({ label: '資遣費金額', formula: `round(${basis} × ${avgWage})`, value: result });

  return {
    avs_version: '1.0',
    function: 'calcSeveranceNew',
    domain: 'labor',
    input: { totalMonths, avgWage },
    laws: [{ article: '勞退條例§12' }],
    steps,
    output: result,
    confidence: 'deterministic',
    law_snapshot_date: '2026-06-13',
    generated_at: new Date().toISOString(),
  };
}

function makeSeveranceOldTrace(totalMonths, avgWage) {
  const years = totalMonths / 12;
  const result = Math.round(years * avgWage);
  return {
    avs_version: '1.0',
    function: 'calcSeveranceOld',
    domain: 'labor',
    input: { totalMonths, avgWage },
    laws: [{ article: '勞基法§17' }],
    steps: [
      { label: '服務年資換算', formula: `${totalMonths} / 12`, value: years },
      { label: '基數計算', formula: `${years} × 1`, value: years },
      { label: '資遣費金額', formula: `${years} × ${avgWage}`, value: result },
    ],
    output: result,
    confidence: 'deterministic',
    law_snapshot_date: '2026-06-13',
    generated_at: new Date().toISOString(),
  };
}

function makeNoticeTrace(calendarMonths, avgWage) {
  let days, amount;
  if (calendarMonths < 3) { days = 0; amount = 0; }
  else if (calendarMonths < 12) { days = 10; amount = Math.round(avgWage / 30 * 10); }
  else if (calendarMonths < 36) { days = 20; amount = Math.round(avgWage / 30 * 20); }
  else { days = 30; amount = Math.round(avgWage / 30 * 30); }
  return {
    avs_version: '1.0',
    function: 'calcNotice',
    domain: 'labor',
    input: { calendarMonths, avgWage },
    laws: [{ article: '勞基法§16' }],
    steps: [
      {
        label: '年資判定',
        formula: `${calendarMonths} < 3 ? 0 : ${calendarMonths} < 12 ? 10 : ${calendarMonths} < 36 ? 20 : 30`,
        value: days,
        note: `服務 ${calendarMonths} 個月 → ${days} 日`,
      },
      { label: '未預告應發工資', formula: `round(${avgWage} / 30 × ${days})`, value: amount },
    ],
    output: { days, amount },
    confidence: 'deterministic',
    law_snapshot_date: '2026-06-13',
    generated_at: new Date().toISOString(),
  };
}

function makeOvertimeTrace(monthlyWage, hours, dayType) {
  const hourly = monthlyWage / 30 / 8;
  let amount, formula;
  if (dayType === 'weekday') {
    const h12 = Math.min(hours, 2);
    const h34 = Math.max(hours - 2, 0);
    amount = Math.round(h12 * hourly * (4/3) + h34 * hourly * (5/3));
    formula = `${h12} × ${hourly.toFixed(4)} × 4 / 3 + ${h34} × ${hourly.toFixed(4)} × 5 / 3`;
  } else {
    amount = Math.round(hours * hourly * 2);
    formula = `${hours} × ${hourly.toFixed(4)} × 2`;
  }
  return {
    avs_version: '1.0',
    function: 'calcOvertimeCost',
    domain: 'labor',
    input: { monthlyWage, hours, dayType },
    laws: [{ article: '勞基法§24' }, { article: '勞基法§39' }],
    steps: [
      { label: '每小時工資', formula: `${monthlyWage} / 30 / 8`, value: hourly },
      { label: '加班費', formula: `round(${formula})`, value: amount },
    ],
    output: amount,
    confidence: 'deterministic',
    law_snapshot_date: '2026-06-13',
    generated_at: new Date().toISOString(),
  };
}

// ── 50 筆測資 ──────────────────────────────────────────────────────────────

const TEST_CASES = [
  // 新制資遣費 × 20
  { label: '新制-1個月-25000',    trace: makeSeveranceNewTrace(1, 25000) },
  { label: '新制-3個月-28000',    trace: makeSeveranceNewTrace(3, 28000) },
  { label: '新制-6個月-30000',    trace: makeSeveranceNewTrace(6, 30000) },
  { label: '新制-12個月-30000',   trace: makeSeveranceNewTrace(12, 30000) },
  { label: '新制-18個月-35000',   trace: makeSeveranceNewTrace(18, 35000) },
  { label: '新制-24個月-35000',   trace: makeSeveranceNewTrace(24, 35000) },
  { label: '新制-30個月-38000',   trace: makeSeveranceNewTrace(30, 38000) },
  { label: '新制-36個月-40000',   trace: makeSeveranceNewTrace(36, 40000) },
  { label: '新制-48個月-40000',   trace: makeSeveranceNewTrace(48, 40000) },
  { label: '新制-60個月-40000',   trace: makeSeveranceNewTrace(60, 40000) },
  { label: '新制-72個月-45000',   trace: makeSeveranceNewTrace(72, 45000) },
  { label: '新制-84個月-48000',   trace: makeSeveranceNewTrace(84, 48000) },
  { label: '新制-96個月-50000',   trace: makeSeveranceNewTrace(96, 50000) },
  { label: '新制-120個月-55000',  trace: makeSeveranceNewTrace(120, 55000) },
  { label: '新制-144個月-60000(觸上限)', trace: makeSeveranceNewTrace(144, 60000) },
  { label: '新制-168個月-65000(觸上限)', trace: makeSeveranceNewTrace(168, 65000) },
  { label: '新制-180個月-70000(觸上限)', trace: makeSeveranceNewTrace(180, 70000) },
  { label: '新制-200個月-80000(觸上限)', trace: makeSeveranceNewTrace(200, 80000) },
  { label: '新制-240個月-50000(觸上限)', trace: makeSeveranceNewTrace(240, 50000) },
  { label: '新制-300個月-100000(觸上限)',trace: makeSeveranceNewTrace(300, 100000) },

  // 舊制資遣費 × 10
  { label: '舊制-12個月-25000',   trace: makeSeveranceOldTrace(12, 25000) },
  { label: '舊制-24個月-30000',   trace: makeSeveranceOldTrace(24, 30000) },
  { label: '舊制-36個月-35000',   trace: makeSeveranceOldTrace(36, 35000) },
  { label: '舊制-60個月-40000',   trace: makeSeveranceOldTrace(60, 40000) },
  { label: '舊制-84個月-45000',   trace: makeSeveranceOldTrace(84, 45000) },
  { label: '舊制-120個月-50000',  trace: makeSeveranceOldTrace(120, 50000) },
  { label: '舊制-126個月-50000',  trace: makeSeveranceOldTrace(126, 50000) },
  { label: '舊制-180個月-60000',  trace: makeSeveranceOldTrace(180, 60000) },
  { label: '舊制-240個月-80000',  trace: makeSeveranceOldTrace(240, 80000) },
  { label: '舊制-360個月-100000', trace: makeSeveranceOldTrace(360, 100000) },

  // 預告工資 × 12
  { label: '預告-1個月（無須預告）',   trace: makeNoticeTrace(1, 26000) },
  { label: '預告-2個月（無須預告）',   trace: makeNoticeTrace(2, 28000) },
  { label: '預告-3個月（臨界10日）',   trace: makeNoticeTrace(3, 30000) },
  { label: '預告-5個月-30000',        trace: makeNoticeTrace(5, 30000) },
  { label: '預告-6個月-36000',        trace: makeNoticeTrace(6, 36000) },
  { label: '預告-9個月-40000',        trace: makeNoticeTrace(9, 40000) },
  { label: '預告-11個月（臨界20日）',  trace: makeNoticeTrace(11, 45000) },
  { label: '預告-12個月（臨界20日）',  trace: makeNoticeTrace(12, 45000) },
  { label: '預告-24個月-50000',       trace: makeNoticeTrace(24, 50000) },
  { label: '預告-35個月（臨界30日）',  trace: makeNoticeTrace(35, 55000) },
  { label: '預告-36個月（臨界30日）',  trace: makeNoticeTrace(36, 55000) },
  { label: '預告-60個月-60000',       trace: makeNoticeTrace(60, 60000) },

  // 加班費 × 8
  { label: '加班費-平日1h-30000',   trace: makeOvertimeTrace(30000, 1, 'weekday') },
  { label: '加班費-平日2h-36000',   trace: makeOvertimeTrace(36000, 2, 'weekday') },
  { label: '加班費-平日3h-36000',   trace: makeOvertimeTrace(36000, 3, 'weekday') },
  { label: '加班費-平日4h-40000',   trace: makeOvertimeTrace(40000, 4, 'weekday') },
  { label: '加班費-假日4h-36000',   trace: makeOvertimeTrace(36000, 4, 'holiday') },
  { label: '加班費-假日6h-45000',   trace: makeOvertimeTrace(45000, 6, 'holiday') },
  { label: '加班費-假日8h-50000',   trace: makeOvertimeTrace(50000, 8, 'holiday') },
  { label: '加班費-假日8h-100000',  trace: makeOvertimeTrace(100000, 8, 'holiday') },
];

// ── 執行 ──────────────────────────────────────────────────────────────────

async function main() {
  const total = TEST_CASES.length;
  console.log(`\n${'═'.repeat(60)}`);
  console.log(`  AVS 壓力測試 — ${total} 筆驗證`);
  console.log(`  AI Verification Standard v1.0`);
  console.log(`${'═'.repeat(60)}\n`);

  let pass = 0, warn = 0, fail = 0;
  const byType = {};
  const times = [];
  const failures = [];

  for (let i = 0; i < TEST_CASES.length; i++) {
    const { label, trace } = TEST_CASES[i];
    const t0 = Date.now();
    const report = await verify(trace, { skipLawVerification: true }); // 本工具專測計算重現，法源由獨立測試覆蓋
    const ms = Date.now() - t0;
    times.push(ms);

    const fn = trace.function;
    if (!byType[fn]) byType[fn] = { pass: 0, fail: 0, warn: 0 };

    const icon = report.overall === 'PASS' ? '✓' : report.overall === 'WARN' ? '△' : '✗';
    if (report.overall === 'PASS') { pass++; byType[fn].pass++; }
    else if (report.overall === 'WARN') { warn++; byType[fn].warn++; }
    else { fail++; byType[fn].fail++; failures.push({ label, errors: report.errors }); }

    const num = String(i + 1).padStart(2, '0');
    console.log(`  ${icon} [${num}/${total}] ${label} — ${report.overall} (${ms}ms)`);
    if (report.overall !== 'PASS' && report.errors.length) {
      report.errors.forEach(e => console.log(`       ↳ ${e}`));
    }
  }

  const avgMs = Math.round(times.reduce((s, t) => s + t, 0) / times.length);
  const maxMs = Math.max(...times);
  const minMs = Math.min(...times);

  console.log(`\n${'═'.repeat(60)}`);
  console.log(`  結果總計`);
  console.log(`${'═'.repeat(60)}`);
  console.log(`  ✓ 通過  ${pass} 筆`);
  console.log(`  △ 警告  ${warn} 筆`);
  console.log(`  ✗ 失敗  ${fail} 筆`);
  console.log(`  通過率  ${((pass + warn) / total * 100).toFixed(1)}%`);
  console.log('');
  console.log(`  分類統計：`);
  for (const [fn, stat] of Object.entries(byType)) {
    const total2 = stat.pass + stat.warn + stat.fail;
    console.log(`    ${fn.padEnd(22)} ✓${stat.pass} △${stat.warn} ✗${stat.fail}  (${total2} 筆)`);
  }
  console.log('');
  console.log(`  效能統計：`);
  console.log(`    平均 ${avgMs}ms / 最快 ${minMs}ms / 最慢 ${maxMs}ms`);

  if (failures.length) {
    console.log(`\n  ❌ 失敗明細：`);
    failures.forEach(({ label, errors }) => {
      console.log(`    · ${label}`);
      errors.forEach(e => console.log(`      ${e}`));
    });
  }

  console.log(`\n  ${pass === total ? '🟢 全部通過' : fail > 0 ? '🔴 有失敗項目' : '🟡 有警告'}`);
  console.log(`${'═'.repeat(60)}\n`);

  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => { console.error('壓測失敗：', e.message, e.stack); process.exit(1); });
