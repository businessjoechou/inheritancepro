#!/usr/bin/env node

import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { rmSync } from 'node:fs';
import { join } from 'node:path';
import { certificationLevel, verify } from '../src/verifier/index.js';
import {
  isOfficialJudgmentUrl,
  verifyJudgmentCitations,
  verifySourceText,
} from '../src/judgment-registry/index.js';

function baseTrace(overrides = {}) {
  return {
    avs_version: '1.0',
    function: 'testCalculation',
    domain: 'civil',
    input: { amount: 100 },
    laws: [{ article: '民法§1138' }],
    steps: [{ label: '輸出', formula: '100', value: 100 }],
    output: 100,
    confidence: 'deterministic',
    law_snapshot_date: '2026-06-24',
    generated_at: '2026-06-24T00:00:00.000Z',
    ...overrides,
  };
}

async function main() {
  const missingInput = baseTrace();
  delete missingInput.input;
  const missingInputReport = await verify(missingInput, { skipLawFetch: true, skipOracle: true });
  assert.equal(missingInputReport.overall, 'FAIL');

  const unchecked = baseTrace({
    steps: [{ label: '不可解析', formula: 'callUnknown(100)', value: 100 }],
  });
  const uncheckedReport = await verify(unchecked, { skipLawFetch: true, skipOracle: true });
  assert.equal(uncheckedReport.phases.computation.status, 'FAIL');
  assert.equal(certificationLevel(uncheckedReport), 'None');

  const offline = await verify(baseTrace(), { skipLawFetch: true, skipOracle: true });
  assert.notEqual(certificationLevel(offline), 'Gold');
  assert.notEqual(certificationLevel(offline), 'Platinum');

  const interpretive = await verify(baseTrace({
    confidence: 'interpretive',
    steps: [{ label: '法院裁量', value: 100 }],
  }), { skipLawVerification: true, skipOracle: true });
  assert.equal(interpretive.overall, 'WARN');
  assert.equal(certificationLevel(interpretive), 'Bronze');

  const oracleMissingAnswer = await verify(baseTrace({
    function: 'calcSeveranceNew',
    domain: 'labor',
    input: { totalMonths: 60, avgWage: 40000 },
    laws: [{ article: '勞退條例§12' }],
    scenario_id: 'TW-LABOR-SEVERANCE-NEW-001',
    output: {},
    steps: [{ label: '輸出', formula: '100000', value: 100000 }],
  }), { skipLawFetch: true });
  assert.equal(oracleMissingAnswer.phases.oracle.status, 'FAIL');

  const inheritanceWrongRatio = await verify(baseTrace({
    function: 'calcInheritanceShare',
    domain: 'civil',
    input: { has_spouse: true, children_count: 2 },
    laws: [{ article: '民法§1138' }, { article: '民法§1144' }],
    scenario_id: 'TW-CIVIL-INHERIT-SHARE-001',
    output: {
      heir_tier: 1,
      spouse_share_fraction: '1/2',
      spouse_share_decimal: 0.5,
      per_child_share_fraction: '1/4',
      per_child_share_decimal: 0.25,
    },
    steps: [{ label: '輸出', formula: '1', value: 1 }],
  }), { skipLawVerification: true });
  assert.equal(inheritanceWrongRatio.phases.oracle.status, 'FAIL');

  assert.equal(isOfficialJudgmentUrl('https://judgment.judicial.gov.tw/FJUD/data.aspx?ty=JD&id=ABC'), true);
  assert.equal(isOfficialJudgmentUrl('https://example.com/FJUD/data.aspx?ty=JD&id=ABC'), false);

  const citation = {
    caseNo: '臺灣臺北地方法院 110 年度簡字第 71 號民事判決',
    judgmentDate: '2021-05-13',
    verifiedAt: '2026-06-24',
    sourceType: '司法院裁判書原文',
    finality: 'unknown',
    sourceUrl: 'https://judgment.judicial.gov.tw/FJUD/data.aspx?ty=JD&id=TEST',
    evidence: ['被告應給付原告新臺幣柒萬陸仟陸佰陸拾捌元', '精神慰撫金以60,000元計算為適當'],
  };
  const sourceText = `
    裁判字號：臺灣臺北地方法院 110 年度簡字第 71 號民事判決
    裁判日期：民國 110 年 05 月 13 日
    被告應給付原告新臺幣柒萬陸仟陸佰陸拾捌元。
    精神慰撫金以60,000元計算為適當。
  `;
  assert.deepEqual(verifySourceText(citation, sourceText).errors, []);

  const badCitationReport = await verifyJudgmentCitations([{
    ...citation,
    sourceUrl: 'https://example.com/not-official',
  }], { offline: true });
  assert.equal(badCitationReport.status, 'FAIL');

  const undeclaredJudgment = await verify(baseTrace({
    output: {
      note: '參考最高法院 110 年度台上字第 1933 號判決',
    },
    steps: [{ label: '輸出', formula: '100', value: 100 }],
  }), { skipLawVerification: true, skipOracle: true });
  assert.equal(undeclaredJudgment.phases.judgment_source.status, 'FAIL');

  const cacheUrl = 'https://judgment.judicial.gov.tw/FJUD/data.aspx?ty=JD&id=AVS-UNIT-TEST';
  const cacheFile = join(
    process.cwd(),
    'judgment-registry-cache',
    `${createHash('sha256').update(cacheUrl).digest('hex')}.json`,
  );
  const notFinalCitation = {
    ...citation,
    finality: 'not-final',
    sourceUrl: cacheUrl,
  };
  const notFinalReport = await verifyJudgmentCitations([notFinalCitation], {
    fetchImpl: async () => ({
      ok: true,
      text: async () => sourceText,
    }),
  });
  assert.equal(notFinalReport.status, 'WARN');

  const changedVerificationDate = await verifyJudgmentCitations([{
    ...notFinalCitation,
    verifiedAt: '2026-06-25',
  }], { offline: true });
  assert.equal(changedVerificationDate.status, 'FAIL');
  rmSync(cacheFile, { force: true });

  console.log('✅ AVS 核心單元測試全部通過');
}

main().catch(error => {
  console.error('❌ AVS 核心單元測試失敗');
  console.error(error);
  process.exit(1);
});
