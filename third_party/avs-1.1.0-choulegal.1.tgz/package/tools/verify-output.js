#!/usr/bin/env node
/**
 * verify-output.js — CLI：驗證任何 AI 輸出的 trace JSON
 *
 * 用法：
 *   node tools/verify-output.js --trace path/to/trace.json
 *   node tools/verify-output.js --trace path/to/trace.json --offline
 *   node tools/verify-output.js --trace path/to/trace.json --report path/to/report.md
 *   node tools/verify-output.js --inline '{"avs_version":"1.0",...}'
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { verify } from '../src/verifier/index.js';
import { generateMarkdownReport, generateSummary } from '../src/report-generator/index.js';

const args = process.argv.slice(2);
const opts = parseArgs(args);

if (!opts.trace && !opts.inline) {
  console.error('用法: node tools/verify-output.js --trace <path> [--offline] [--report <output-path>]');
  process.exit(1);
}

async function main() {
  let trace;

  try {
    if (opts.inline) {
      trace = JSON.parse(opts.inline);
    } else {
      const raw = readFileSync(resolve(opts.trace), 'utf8');
      trace = JSON.parse(raw);
    }
  } catch (e) {
    console.error(`❌ 無法讀取 trace：${e.message}`);
    process.exit(1);
  }

  console.log(`\n正在驗證：${trace.function ?? '(未知函式)'}...`);
  if (opts.offline) console.log('（離線模式，略過法源網路查核）');

  const report = await verify(trace, {
    skipLawFetch: opts.offline ?? false,
    skipOracle: opts.skipOracle ?? false,
  });

  const summary = generateSummary(report);
  console.log('\n' + summary);

  if (opts.report) {
    const md = generateMarkdownReport(report, trace);
    const outPath = resolve(opts.report);
    writeFileSync(outPath, md, 'utf8');
    console.log(`\n📄 詳細報告已儲存：${outPath}`);
  }

  if (opts.json) {
    console.log('\n--- JSON 報告 ---');
    console.log(JSON.stringify(report, null, 2));
  }

  process.exit(report.overall === 'FAIL' ? 1 : 0);
}

function parseArgs(args) {
  const result = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--trace') result.trace = args[++i];
    else if (args[i] === '--inline') result.inline = args[++i];
    else if (args[i] === '--report') result.report = args[++i];
    else if (args[i] === '--offline') result.offline = true;
    else if (args[i] === '--skip-oracle') result.skipOracle = true;
    else if (args[i] === '--json') result.json = true;
  }
  return result;
}

main().catch(e => {
  console.error('驗證過程發生錯誤：', e.message);
  process.exit(1);
});
