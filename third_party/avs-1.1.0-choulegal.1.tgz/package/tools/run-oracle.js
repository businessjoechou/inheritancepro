#!/usr/bin/env node
/**
 * run-oracle.js — CLI：驗證 oracle 庫的完整性（產品中立）
 *
 * 注意：這個工具只驗證 oracle 庫本身的格式正確性與完整性。
 * 它不執行任何 AI 產品的計算。
 *
 * 若要測試特定產品是否能正確回答所有 oracle 場景，
 * 請使用各產品的 adapter（如 adapters/choulegal/demo-e2e.js）。
 *
 * 用法：
 *   node tools/run-oracle.js                    全部
 *   node tools/run-oracle.js --domain labor     只驗指定法域
 *   node tools/run-oracle.js --report out.md    輸出報告
 */

import { readdirSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ORACLE_DIR = join(__dirname, '../test-oracles');
const REPORTS_DIR = join(__dirname, '../reports');

const args = process.argv.slice(2);
const opts = parseArgs(args);

const REQUIRED_SCENARIO_FIELDS = [
  'scenario_id', 'title', 'jurisdiction', 'domain',
  'law_snapshot_date', 'facts', 'legal_question',
  'expected_answer', 'applicable_laws', 'verification_constraints', 'human_verification',
];

async function main() {
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  AVS Oracle 庫完整性驗證');
  console.log('  AI Verification Standard — 場景庫格式查核');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  const domains = opts.domain
    ? [opts.domain]
    : readdirSync(ORACLE_DIR).filter(d => {
        try { return readdirSync(join(ORACLE_DIR, d)).length > 0; } catch { return false; }
      });

  const allResults = [];
  let totalPass = 0, totalFail = 0;
  let duplicateCount = 0;
  const scenarioIds = new Set(); // 全域唯一性檢查

  for (const domain of domains) {
    const domainDir = join(ORACLE_DIR, domain);
    if (!existsSync(domainDir)) {
      console.log(`⚠️  找不到 domain：${domain}`);
      continue;
    }

    const files = readdirSync(domainDir).filter(f => f.endsWith('.json'));
    console.log(`📂 ${domain.toUpperCase()} (${files.length} 個場景檔案)`);

    for (const file of files) {
      let db;
      try {
        db = JSON.parse(readFileSync(join(domainDir, file), 'utf8'));
      } catch (e) {
        console.log(`   ✗ ${file} — JSON 解析失敗: ${e.message}`);
        totalFail++;
        continue;
      }

      const scenarios = db.scenarios ?? [];
      console.log(`   📋 ${file} — ${scenarios.length} 個場景`);

      for (const scenario of scenarios) {
        const result = validateScenario(scenario, scenarioIds);
        allResults.push({ domain, file, scenario, result });

        const icon = result.pass ? '✓' : '✗';
        const detail = result.pass ? `PASS` : `FAIL — ${result.errors.join('; ')}`;
        const sid = scenario.scenario_id ?? '(無 scenario_id)';
        console.log(`      ${icon} [${sid}] ${(scenario.title ?? '').slice(0, 40)} — ${detail}`);

        if (result.pass) totalPass++; else totalFail++;
        if (result.errors.some(error => error.startsWith('scenario_id 重複:'))) duplicateCount++;
        if (scenario.scenario_id) scenarioIds.add(scenario.scenario_id);
      }
    }
    console.log('');
  }

  const total = totalPass + totalFail;
  const allPassed = totalFail === 0;
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`${allPassed ? '✅' : '❌'} 結果：${totalPass}/${total} 通過`);
  console.log(`   場景 ID 全域唯一：${scenarioIds.size} 個，${duplicateCount === 0 ? '無重複' : `重複 ${duplicateCount} 個`}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  if (opts.report) {
    const md = generateReport(allResults, { totalPass, totalFail, total });
    if (!existsSync(REPORTS_DIR)) mkdirSync(REPORTS_DIR, { recursive: true });
    const outPath = opts.report.startsWith('/') ? opts.report : join(REPORTS_DIR, opts.report);
    writeFileSync(outPath, md, 'utf8');
    console.log(`📄 報告已儲存：${outPath}`);
  }

  process.exit(totalFail > 0 ? 1 : 0);
}

function validateScenario(s, existingIds) {
  const errors = [];
  const officialHosts = new Set([
    'law.moj.gov.tw',
    'laws.mol.gov.tw',
    'calcr2.mol.gov.tw',
    'judgment.judicial.gov.tw',
    'legal.judicial.gov.tw',
    'cons.judicial.gov.tw',
    'www.moi.gov.tw',
    'www.land.moi.gov.tw',
    'pip.moi.gov.tw',
  ]);

  // 必要欄位
  for (const field of REQUIRED_SCENARIO_FIELDS) {
    if (!(field in s)) errors.push(`缺少欄位: ${field}`);
  }

  // scenario_id 格式
  if (s.scenario_id && !/^[A-Z]{2}-[A-Z]+-[A-Z-]+-\d{3}$/.test(s.scenario_id)) {
    errors.push(`scenario_id 格式不符（應為 TW-LABOR-TOPIC-001）: ${s.scenario_id}`);
  }

  // scenario_id 全域唯一
  if (s.scenario_id && existingIds.has(s.scenario_id)) {
    errors.push(`scenario_id 重複: ${s.scenario_id}`);
  }

  // applicable_laws 至少一條
  if (!Array.isArray(s.applicable_laws) || s.applicable_laws.length === 0) {
    errors.push('applicable_laws 至少需要一條');
  } else {
    for (const law of s.applicable_laws) {
      if (!law.article) errors.push('applicable_laws 每筆都必須有 article');
      if (!isOfficialUrl(law.url, officialHosts)) {
        errors.push(`法條來源不是官方 HTTPS 網址：${law.article ?? '(未知法條)'}`);
      }
    }
  }

  // verification_constraints.laws_must_cite 必須有內容
  if (!s.verification_constraints?.laws_must_cite?.length) {
    errors.push('verification_constraints.laws_must_cite 不得為空');
  } else {
    const applicableArticles = new Set((s.applicable_laws ?? []).map(law => law.article));
    for (const article of s.verification_constraints.laws_must_cite) {
      if (!applicableArticles.has(article)) errors.push(`laws_must_cite 未列於 applicable_laws：${article}`);
    }
  }

  // human_verification.verified_at 必須有
  if (!s.human_verification?.verified_at) {
    errors.push('human_verification.verified_at 缺失');
  }
  if (!s.human_verification?.authority_citations?.length) {
    errors.push('human_verification.authority_citations 不得為空');
  }

  if (!Array.isArray(s.authority_sources) || s.authority_sources.length === 0) {
    errors.push('authority_sources 至少需要一個官方權威來源');
  } else {
    for (const source of s.authority_sources) {
      for (const key of ['url', 'query_url']) {
        if (source[key] && !isOfficialUrl(source[key], officialHosts)) {
          errors.push(`authority_sources.${key} 不是允許的官方 HTTPS 網址：${source[key]}`);
        }
      }
    }
  }

  // expected_answer 必須有實質內容
  const ea = s.expected_answer;
  if (!ea || Object.keys(ea).filter(k => k !== 'basis').length === 0) {
    errors.push('expected_answer 缺少可驗證的答案欄位（amount_twd / notice_days / ratio 等）');
  }

  return { pass: errors.length === 0, errors };
}

function isOfficialUrl(value, officialHosts) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && officialHosts.has(url.hostname);
  } catch {
    return false;
  }
}

function generateReport(results, stats) {
  const lines = [
    '# AVS Oracle 庫完整性驗證報告',
    `**產生時間：** ${new Date().toISOString()}`,
    `**結果：** ${stats.totalPass}/${stats.total} 通過`,
    '',
  ];
  const byDomain = {};
  for (const r of results) {
    if (!byDomain[r.domain]) byDomain[r.domain] = [];
    byDomain[r.domain].push(r);
  }
  for (const [domain, rs] of Object.entries(byDomain)) {
    lines.push(`## ${domain.toUpperCase()}`);
    for (const { scenario, result } of rs) {
      const icon = result.pass ? '✅' : '❌';
      lines.push(`- ${icon} \`${scenario.scenario_id}\` — ${scenario.title}`);
      if (!result.pass) result.errors.forEach(e => lines.push(`  - ${e}`));
    }
    lines.push('');
  }
  lines.push('---');
  lines.push('*由 AVS run-oracle.js 自動產生*');
  return lines.join('\n');
}

function parseArgs(args) {
  const r = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--domain') r.domain = args[++i];
    else if (args[i] === '--report') r.report = args[++i];
  }
  return r;
}

main().catch(e => { console.error('執行失敗：', e.message); process.exit(1); });
