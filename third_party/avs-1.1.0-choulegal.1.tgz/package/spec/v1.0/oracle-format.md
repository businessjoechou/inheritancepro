# Oracle Format Specification — AVS v1.0
# 測試神諭格式規格

Oracle 是由人工確認的「法律場景標準答案庫」。
它描述的是**法律事實**，不是任何特定產品的實作。

---

## 設計原則

1. **產品中立**：Oracle 不知道任何 AI 產品存在，不綁定任何函式名稱
2. **場景驅動**：以人看得懂的「法律事實」描述問題，而非程式參數
3. **來源可追溯**：每個答案都有人工確認的法律依據
4. **任何人可驗**：下載 oracle 庫，任何 AI 系統都可以自我測試

---

## 核心概念

```
[法律場景] → 任何 AI 系統嘗試回答 → 提交 AVS trace → verifier 比對 oracle
```

AI 系統在 trace 的 `scenario_id` 欄位宣告「我在回答哪個場景」，
verifier 就能找到對應的 oracle 標準答案進行比對。

---

## 單一 Oracle 案例格式

```json
{
  "scenario_id": "TW-LABOR-SEVERANCE-NEW-001",
  "title": "新制資遣費計算：服務 5 年、月薪 40,000 元",
  "jurisdiction": "TW",
  "domain": "labor",
  "version": "1.0",
  "law_snapshot_date": "2026-06-13",

  "facts": {
    "description": "勞工甲在同一雇主服務滿 5 年，採新制（勞工退休金條例），月平均薪資 40,000 元。雇主依勞基法第 11 條第 5 款終止勞動契約。",
    "structured": {
      "retirement_system": "new",
      "service_months": 60,
      "avg_monthly_wage_twd": 40000,
      "termination_ground": "勞基法§11"
    }
  },

  "legal_question": "雇主應給付多少新制資遣費（新臺幣）？",

  "expected_answer": {
    "amount_twd": 100000,
    "basis": "60個月 ÷ 12 × 0.5個月 × 40,000元 = 100,000元，未觸及6個月上限"
  },

  "applicable_laws": [
    {
      "article": "勞退條例§12",
      "pcode": "N0030020",
      "role": "primary",
      "key_provision": "每滿一年發給二分之一個月之平均工資，最高以六個月為限"
    }
  ],

  "verification_constraints": {
    "answer_tolerance_twd": 1,
    "laws_must_cite": ["勞退條例§12"],
    "reasoning_steps_min": 3,
    "confidence_required": "deterministic"
  },

  "human_verification": {
    "verified_by": "ChouLegal-internal",
    "verified_at": "2026-06-13",
    "method": "對照全國法規資料庫條文原文人工計算",
    "notes": "5年×0.5=2.5個月基數，2.5×40,000=100,000，未觸上限"
  },

  "edge_cases": [],
  "related_scenarios": ["TW-LABOR-SEVERANCE-NEW-002"]
}
```

---

## 欄位說明

### `scenario_id`
格式：`{法域代碼}-{法律領域}-{情境}-{序號}`
- 法域代碼：`TW`（台灣）、`US`、`EU`、`JP`
- 法律領域：`LABOR`、`CIVIL`、`CONSUMER`、`RENTAL`、`TAX`
- 情境：英文大寫縮寫，如 `SEVERANCE-NEW`、`NOTICE`
- 序號：三位數，如 `001`

### `facts.structured`
機器可讀的事實，格式因法律場景而異。
重要：**不使用任何產品特定的參數名稱**，用法律語言（如 `service_months` 而非 `totalMonths`）。

### `expected_answer`
- `amount_twd`：數字，新臺幣金額
- `days`：天數（預告期等）
- `ratio`：比例（應繼分等）
- `result_object`：複合結果（含多個欄位）

### `verification_constraints`
- `answer_tolerance_twd`：數值誤差容忍度（元）
- `laws_must_cite`：trace 必須引用的法條
- `reasoning_steps_min`：最少計算步驟數
- `confidence_required`：要求的信心等級

### `human_verification.verified_by`
- `ChouLegal-internal`：本公司內部核查（最低等級，公開標記）
- `律師審查：[姓名/字號]`：執業律師確認
- `行政函釋：[字號]`：官方函釋
- `判決：[字號]`：法院判決

---

## 批次檔案格式

```json
{
  "schema_version": "1.0",
  "jurisdiction": "TW",
  "domain": "labor",
  "topic": "severance",
  "last_updated": "2026-06-13",
  "maintainer": "ChouLegal",
  "scenarios": [
    { ...場景1... },
    { ...場景2... }
  ]
}
```

---

## AI 系統如何使用 Oracle

提交的 AVS trace 中加上 `scenario_id`：

```json
{
  "avs_version": "1.0",
  "scenario_id": "TW-LABOR-SEVERANCE-NEW-001",
  "function": "calcSeveranceNew",
  "domain": "labor",
  ...
}
```

Verifier 收到後：
1. 從 `scenario_id` 找到對應 oracle
2. 比對 `output` 是否符合 `expected_answer`
3. 確認 `laws` 包含 `applicable_laws` 中的必要法條
4. 確認 trace 符合 `verification_constraints`

---

## 為什麼不用函式名稱？

```
❌ 舊設計（產品綁定）：
   oracle.function = "calcSeveranceNew"   ← 這是 ChouLegal 的函式名，別家不叫這個

✅ 新設計（產品中立）：
   oracle.scenario_id = "TW-LABOR-SEVERANCE-NEW-001"   ← 任何系統都能宣稱回答這個場景
```

任何系統，不論是 ChouLegal、Harvey、政府系統，
只要宣稱能回答「TW-LABOR-SEVERANCE-NEW-001」這個場景，
就可以用 AVS 驗證自己的答案是否正確。
