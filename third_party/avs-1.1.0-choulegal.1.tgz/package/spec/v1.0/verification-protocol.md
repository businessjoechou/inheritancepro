# Verification Protocol — AVS v1.0
# 驗證協議

---

## 驗證流程

獨立驗證器接收一份 `trace.json`，執行以下驗證：

```
Phase 1: 結構驗證 (Schema Validation)
Phase 2: 法源查核 (Law Source Verification)
Phase 2B: 裁判來源查核 (Judgment Citation Verification)
Phase 3: 計算重現 (Step Re-computation)
Phase 4: Oracle 比對 (Oracle Matching)
```

Phase 1 失敗時立即停止；其餘階段盡可能完成，以便一次列出全部錯誤。任何階段 FAIL，整體即為 FAIL。

---

## Phase 1：結構驗證

驗證 trace 符合 `trace-schema.json`。

**通過條件：**
- trace 是合法 JSON
- 所有 `required` 欄位均存在
- 欄位類型符合 Schema 定義
- `avs_version` 為已知版本

**失敗類型：**
- `STRUCTURE_INVALID` — JSON 格式錯誤
- `SCHEMA_VIOLATION` — 欄位缺失或類型錯誤
- `UNKNOWN_VERSION` — avs_version 不支援

---

## Phase 2：法源查核

逐條驗證 `trace.laws` 中每條法律的真實性。

**步驟：**
1. 查詢本地法源登記冊（`law-registry/cache/`）
2. 若登記冊無此條文，從 `law.moj.gov.tw` 抓取
3. 計算抓取內容的 SHA-256 hash
4. 比對 trace 中的 `source_hash`（若有）

**通過條件：**
- 所有法條均可在 `law.moj.gov.tw` 找到
- 若 trace 提供 `source_hash`，與當前版本 hash 一致
- 若 hash 不一致，標記為「法條已更新」並報告差異

**失敗類型：**
- `LAW_NOT_FOUND` — 法條不存在（疑似幻覺）
- `LAW_HASH_MISMATCH` — 法條內容已修改（版本不符）
- `LAW_REPEALED` — 法條已廢止
- `PCODE_MISMATCH` — pcode 對應不同法律

**注意：** 法條已更新不一定代表計算錯誤，但必須標記，由人工判斷是否影響結果。

---

## Phase 2B：裁判來源查核

只要輸出包含裁判案號、裁判摘要、裁判金額或實務見解，必須提供 `judgments`。

**通過條件：**
- URL 為司法院裁判書系統官方 HTTPS 網址
- 官方頁面裁判字號與 `caseNo` 完全一致
- 官方裁判日期與 `judgmentDate` 一致
- 至少兩段 `evidence` 可在官方原文逐字找到
- 離線模式存在先前由 AVS 官方連線驗證產生的快取，且資料指紋一致
- trace 其他欄位出現裁判案號時，該案號必須列入 `judgments`
- `not-final` 與 `unknown` 只可得到 WARN，不得取得 Gold 或 Platinum
- `verifiedAt` 納入快取指紋，修改查核日期後必須重新連線驗證

---

## Phase 3：計算重現

逐步重新執行 `trace.steps` 中的每個計算步驟。

**步驟：**
1. 從 `trace.input` 取得初始值
2. 依序執行每個 step 的 `formula`
3. 比對 step 的 `value` 與重新計算結果
4. 預設允許誤差：數值型 ±0.01；需要整數四捨五入時，公式必須明寫 `round()`

**通過條件：**
- 每個 step 的重算結果與 `value` 誤差 ≤ 0.01
- 最終 step 結果與 `trace.output` 一致
- 計算鏈無斷裂（每個 step 的 inputs 可從前序 steps 追溯）

**失敗類型：**
- `STEP_MISMATCH` — 步驟計算值不符
- `STEP_UNCHECKED` — deterministic / rule-based 步驟缺少公式或公式無法解析
- `OUTPUT_MISMATCH` — 最終輸出不符
- `CHAIN_BROKEN` — 計算步驟無法串連

**Formula 解析規則：**

驗證器支援以下 formula 語法：
- 算術：`+`, `-`, `×`, `/`, `min(a, b)`, `max(a, b)`, `Math.ceil()`, `Math.floor()`
- 比較：JavaScript 三元運算式 `condition ? valueA : valueB`
- 函式：`round()`, `floor()`, `ceil()`, `min()`, `max()`
- 參照：輸入參數名稱或當步驟 `inputs` 中的名稱

---

## Phase 4：Oracle 比對

若此計算函式有對應的 oracle 案例，且輸入與某個 oracle 的 `input` 相符，比對輸出。

**步驟：**
1. 從 `test-oracles/{domain}/` 找對應 oracle 案例
2. 依 `function` 和 `input` 精確匹配
3. 比對 `output` 與 oracle 的 `expected_output`
4. 驗證 trace 符合 oracle 的 `expected_trace_constraints`

**通過條件：**
- 找不到匹配 oracle：跳過此 phase，標記 `ORACLE_NOT_FOUND`（非失敗）
- 找到匹配：output 與 expected_output 誤差 ≤ 1 元（整數捨入）

**失敗類型：**
- `ORACLE_OUTPUT_MISMATCH` — 輸出與人工確認值不符
- `ORACLE_TRACE_CONSTRAINT_FAIL` — trace 不符合 oracle 約束

---

## 驗證結果格式

```json
{
  "avs_version": "1.0",
  "verified_at": "2026-06-13T10:00:00Z",
  "trace_function": "calcSeveranceNew",
  "overall": "PASS | FAIL | WARN",
  "phases": {
    "schema": { "status": "PASS" },
    "law_source": {
      "status": "PASS",
      "items": [
        {
          "article": "勞退條例§12",
          "status": "VERIFIED",
          "source_url": "https://law.moj.gov.tw/...",
          "hash_match": true
        }
      ]
    },
    "computation": {
      "status": "PASS",
      "steps_verified": 3,
      "steps_failed": 0
    },
    "oracle": {
      "status": "PASS",
      "oracle_id": "labor-severance-new-001",
      "expected": 100000,
      "actual": 100000
    }
  },
  "warnings": [],
  "errors": []
}
```

---

## 整體結論規則

| 條件 | 整體結論 |
|---|---|
| 所有 phase PASS | `PASS` |
| 有任一 phase FAIL | `FAIL` |
| 無 FAIL，但有法條更新警告 | `WARN` |
| 無 FAIL，無 oracle 匹配 | `PASS` （標記 `oracle_not_tested`） |

---

## 獨立運行方式

驗證器設計為任何第三方可獨立架設：

```bash
# 安裝
npm install

# 驗證單一 trace
node tools/verify-output.js --trace path/to/trace.json

# 跑全套 oracle
node tools/run-oracle.js

# 更新法源登記冊
node tools/fetch-law.js --update-all
```

驗證器**不需要 AI API**，也不需要連接任何 ChouLegal 服務。唯一的外部依賴是 `law.moj.gov.tw`（台灣政府官方網站）。
