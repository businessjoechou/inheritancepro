# AVS — AI Verification Standard

**Open protocol for proving that AI-generated legal computations are correct.**

No AI in the verifier. No black boxes. Every calculation re-computed from first principles, checked against official law text.

[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![Node ≥18](https://img.shields.io/badge/node-%3E%3D18-brightgreen)](https://nodejs.org)
[![Oracle 17/17](https://img.shields.io/badge/oracle-17%2F17-green)]()
[![Stress 50/50](https://img.shields.io/badge/stress%20test-50%2F50-green)]()

---

## Why AVS?

AI systems generating legal outputs face a fundamental trust problem: *how do you prove the answer is right?*

AVS uses a deterministic verification pipeline — **no AI required in the verifier**:

```
Your AI output (trace JSON)
  │
  ├─ Phase 1: Schema Validation    ─ Are all required fields present?
  ├─ Phase 2: Law Source Check     ─ Does every cited article exist in the official registry?
  ├─ Phase 2B: Judgment Check      ─ Do cited cases match official Judicial Yuan text?
  ├─ Phase 3: Step Re-computation  ─ Does every formula re-compute to the same value?
  └─ Phase 4: Oracle Matching      ─ Does the answer match a human-verified reference case?
         │
         └─► PASS / WARN / FAIL  +  machine-readable audit trail
```

AVS also scans trace text for Taiwan court case-number patterns. If a case number appears outside `judgments` but has no matching declared citation, verification fails.

Any third party — a government agency, a court, a competitor — can run the verifier independently and get the same result.

---

## Quick Start

```bash
npm install avs
```

```js
import { verify } from 'avs/verifier';

const trace = {
  avs_version: '1.0',
  function: 'calcSeveranceNew',
  scenario_id: 'TW-LABOR-SEVERANCE-NEW-001',   // optional: enables oracle matching
  domain: 'labor',
  input: { totalMonths: 60, avgWage: 40000 },
  laws: [{
    article: '勞退條例§12',
    source_hash: 'c41feabe56976ce3bc78be60ea60f289b9d2139601fe70c6e0b213bccd4fbef3',
    fetched_at: '2026-06-13',
    source_url: 'https://law.moj.gov.tw/LawClass/LawSingle.aspx?pcode=N0030020&flno=12',
  }],
  steps: [
    { label: 'Service years',   formula: '60 / 12',      value: 5 },
    { label: 'Severance basis', formula: '5 × 0.5',      value: 2.5 },
    { label: 'Amount',          formula: '2.5 × 40000',  value: 100000 },
  ],
  output: 100000,
  confidence: 'deterministic',
  law_snapshot_date: '2026-06-13',
  generated_at: new Date().toISOString(),
};

const report = await verify(trace);
// report.overall  → 'PASS'
// report.phases   → { schema, law_source, judgment_source, computation, oracle }
```

---

## CLI

```bash
# Validate 17 oracle reference scenarios
npx avs oracle

# Verify any AI system's trace output
npx avs verify --trace my-ai-output.json
npx avs verify --trace my-ai-output.json --report audit.md --offline

# Manage law source cache (Taiwan law.moj.gov.tw)
npx avs fetch-law --list
npx avs fetch-law --article "勞基法§17"
npx avs fetch-law --update-all

# Verify court citations against Judicial Yuan official text
npx avs judgments --manifest judgments.json
```

---

## Architecture

AVS is **completely product-agnostic**. The core knows nothing about any specific AI system.

```
Any AI System (Harvey, ChatGPT, ChouLegal, your product...)
    ↓  writes an AVS trace JSON (adapter handles translation)
AVS Verifier  (src/verifier/)
    ↓  deterministic source + computation + oracle checks
Audit Report   (src/report-generator/)
    ↓  Markdown or JSON — shareable, archivable, court-ready
```

Your AI system writes an **adapter** that maps its output to an AVS trace. See `adapters/README.md` for examples.

---

## Confidence Levels

| Level | Meaning | Verifiable |
|---|---|---|
| `deterministic` | Pure statutory formula — e.g. "severance = basis × wage" | ✅ Full re-computation |
| `rule-based` | If/else from regulation text | ✅ Logic trace |
| `interpretive` | Judgment call with discretion | ⚠ Cite reasoning only |
| `unverifiable` | Requires human expert | 🔴 Flag for manual review |

---

## Oracle Reference Scenarios

17 human-verified scenarios across 4 legal domains:

| Domain | Count | Key Laws |
|---|---|---|
| Labor — Severance (new system) | 4 | 勞退條例§12 |
| Labor — Severance (old system) | 1 | 勞基法§17 |
| Labor — Notice period | 4 | 勞基法§16 |
| Labor — Overtime | 3 | 勞基法§24/§39 |
| Civil — Inheritance share | 3 | 民法§1138/§1144 |
| Rental — Deposit cap | 3 | 土地法§99 / 租賃專法§7 |

Scenario IDs: `{JX}-{DOMAIN}-{TOPIC}-{SEQ}` → `TW-LABOR-SEVERANCE-NEW-001`

Any AI system can **claim** to answer any scenario. The verifier checks:
- Answer value (within 1 TWD tolerance)
- Required law articles cited
- Minimum reasoning steps
- Confidence level

---

## Law Source Registry

33 Taiwan law articles pre-fetched and SHA-256 hashed from [law.moj.gov.tw](https://law.moj.gov.tw) (the official government registry):

```bash
npx avs fetch-law --list       # see all 33
npx avs fetch-law --update-all # refresh from law.moj
```

When an article is amended, the hash changes → verifier automatically emits `WARN: law updated since trace was generated`.

---

## Stress Test Results

ChouLegal verified 50 independent computation cases covering full input ranges:

```
✓ calcSeveranceNew   20/20  (1–300 months, 25,000–100,000 TWD/mo, cap tests included)
✓ calcSeveranceOld   10/10  (12–360 months, no cap)
✓ calcNotice         12/12  (1–60 months, all boundary cases: 0/10/20/30 days)
✓ calcOvertimeCost    8/8   (weekday + holiday, 1–8 hours)
────────────────────────────────────────────────────────
Pass rate: 50/50 — 100%    avg 0ms/case (offline, cached laws)
```

```bash
node tools/stress-test.js    # run it yourself
```

---

## Adding Oracle Scenarios

Add a file under `test-oracles/<domain>/<topic>.json`:

```json
{
  "scenarios": [{
    "scenario_id": "TW-LABOR-SEVERANCE-NEW-001",
    "title": "New severance: 5 years, 40,000 TWD/mo",
    "jurisdiction": "TW",
    "domain": "labor",
    "law_snapshot_date": "2026-01-01",
    "facts": {
      "language": "zh-TW",
      "structured": {
        "retirement_system": "new",
        "service_months": 60,
        "avg_monthly_wage_twd": 40000
      }
    },
    "legal_question": "What is the severance pay under 勞退條例§12?",
    "expected_answer": {
      "amount_twd": 100000,
      "basis": "60÷12=5yr × 0.5mo = 2.5 basis × 40,000 = 100,000 (cap 6mo not triggered)"
    },
    "applicable_laws": ["勞退條例§12"],
    "verification_constraints": {
      "laws_must_cite": ["勞退條例§12"],
      "reasoning_steps_min": 2,
      "confidence_required": "deterministic",
      "answer_tolerance_twd": 1
    },
    "human_verification": {
      "verified_by": "ChouLegal",
      "verified_at": "2026-06-13",
      "method": "manual cross-check with law.moj.gov.tw + Ministry of Labor official guidance"
    }
  }]
}
```

Then validate: `npx avs oracle`

---

## Implementing AVS — Minimum Trace

Any language, any system. Just produce this JSON:

```json
{
  "avs_version": "1.0",
  "function": "calcSeveranceNew",
  "domain": "labor",
  "input": { "totalMonths": 60, "avgWage": 40000 },
  "laws": [{
    "article": "勞退條例§12",
    "source_hash": "c41feabe56976ce3bc78be60ea60f289b9d2139601fe70c6e0b213bccd4fbef3",
    "fetched_at": "2026-06-13",
    "source_url": "https://law.moj.gov.tw/LawClass/LawSingle.aspx?pcode=N0030020&flno=12"
  }],
  "steps": [
    { "label": "Service years",   "formula": "60 / 12",     "value": 5 },
    { "label": "Basis",           "formula": "5 × 0.5",     "value": 2.5 },
    { "label": "Severance",       "formula": "2.5 × 40000", "value": 100000 }
  ],
  "output": 100000,
  "confidence": "deterministic",
  "law_snapshot_date": "2026-06-13",
  "generated_at": "2026-06-13T00:00:00Z"
}
```

Add `scenario_id` to enable oracle matching. See `spec/v1.0/trace-schema.json` for the full schema.

---

## Repository Structure

```
avs/
├── src/
│   ├── verifier/          Core verification pipeline (product-agnostic)
│   ├── law-registry/      Law source fetcher + SHA-256 cache
│   ├── judgment-registry/ Judicial Yuan citation verifier
│   └── report-generator/  Markdown & text report output
├── test-oracles/          Human-verified reference scenarios
│   ├── labor/             severance, notice, overtime
│   ├── civil/             inheritance
│   └── rental/            deposit
├── spec/v1.0/             Formal specification
│   ├── trace-schema.json
│   ├── oracle-format.md
│   └── verification-protocol.md
├── tools/                 CLI tools (run-oracle, verify-output, stress-test)
├── bin/                   npm bin entry point (avs CLI)
├── adapters/              Product-specific adapters (NOT part of AVS core)
│   └── choulegal/         ChouLegal implementation example
├── law-registry-cache/    SHA-256 hashed law texts (auto-managed)
└── STANDARD.md            Full open standard specification
```

---

## License

**CC BY 4.0** — Use freely, implement in your product, fork, extend.

Required attribution: *"Uses AVS — AI Verification Standard by ChouLegal"*

When building with AVS, you are encouraged (not required) to:
- Publish which oracle scenarios your product passes
- Open-source your adapter
- Contribute new oracle scenarios via pull request

---

## About

Developed by [ChouLegal 周全法律科技](https://choulegal.com) (Taiwan).

AVS was designed from day one to be completely product-agnostic. ChouLegal implements it; any other legal AI worldwide can do the same.

> *"If an AI legal system can't prove it's right, it shouldn't be trusted with legal questions."*
