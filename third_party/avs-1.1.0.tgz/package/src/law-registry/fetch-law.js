/**
 * fetch-law.js — 法源登記冊：從 law.moj.gov.tw 抓取法條並計算 hash
 *
 * 這是整個 AVS 驗證系統的信任根基。
 * 驗證器不信任 AI 說的任何法條文字，只信任此模組從官方來源取得的內容。
 */

import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CACHE_DIR = join(__dirname, '../../law-registry-cache');

function lawEntries(name, pcode, articles, aliases = []) {
  const names = [name, ...aliases];
  return Object.fromEntries(
    names.flatMap((lawName) => articles.map((flno) => [
      `${lawName}§${flno}`,
      { pcode, flno, name },
    ])),
  );
}

/**
 * 已知法條的 law.moj pcode + 條號對照表
 * SSOT: 對齊 apps/workers/ai-triage/src/law-registry.ts（2026-06-13 驗証）
 */
const KNOWN_LAWS = {
  ...lawEntries('民法', 'B0000001', [
    '13', '125', '126', '127', '128', '129', '130', '137', '139', '140', '141', '142', '143', '144',
    '184', '185', '187', '188', '191-2', '192', '193', '194', '195', '197',
    '203', '205', '213', '216', '217', '229', '233', '244', '245',
    '736', '737', '738', '1005', '1017', '1020-1', '1030', '1030-1', '1030-3', '1030-4',
    '1050', '1052', '1055', '1055-1', '1056', '1057', '1065', '1084',
    '1116-2', '1117', '1118-1', '1119', '1132', '1137',
    '1138', '1140', '1141', '1144', '1146', '1148', '1148-1', '1149',
    '1151', '1153', '1154', '1156', '1157', '1159', '1160', '1162-2', '1164', '1165',
    '1173', '1174', '1176', '1185', '1186', '1187',
    '1189', '1190', '1191', '1192', '1193', '1194', '1195', '1196', '1197', '1198', '1209',
    '1219', '1220', '1221', '1222', '1223', '1224', '1225',
  ]),
  ...lawEntries('保險法', 'G0390002', [
    '3', '4', '6', '13', '17', '18', '34', '35', '38', '64', '65', '103', '107', '108', '110', '111', '112',
    '113', '116', '119', '120', '131',
  ]),
  ...lawEntries('中華民國刑法', 'C0000001', ['344', '356'], ['刑法']),
  ...lawEntries('民事訴訟法', 'B0010001', ['1', '522'], ['民訴']),
  ...lawEntries('強制汽車責任保險法', 'G0390060', ['7', '25', '27', '32', '40', '42']),
  ...lawEntries('強制汽車責任保險給付標準', 'G0390067', ['2', '3', '6', '7']),
  ...lawEntries('遺產及贈與稅法', 'G0340072', [
    '1', '4', '5', '5-1', '10', '11', '12-1', '13', '15', '16', '16-1', '17', '17-1', '18', '19', '20', '20-1', '22', '23', '24', '26', '44', '45', '46',
  ], ['遺贈稅']),
  ...lawEntries('遺產及贈與稅法施行細則', 'G0340073', ['21', '28', '29'], ['遺贈稅法施行細則']),
  ...lawEntries('所得基本稅額條例', 'G0340115', ['4', '12', '13', '14']),
  ...lawEntries('所得稅法', 'G0340003', [
    '4-4', '4-5', '14', '14-4', '14-5', '14-6', '14-7', '14-8', '24', '71', '71-1',
  ], ['所']),
  ...lawEntries('房屋稅條例', 'G0340102', ['4', '5', '15']),
  ...lawEntries('稅捐稽徵法', 'G0340001', ['21', '28', '35', '41']),
  ...lawEntries('土地稅法', 'G0340096', ['14', '17', '28-1']),
  ...lawEntries('土地法', 'D0060001', ['73']),
  ...lawEntries('戶籍法', 'D0030006', ['47', '48']),
  ...lawEntries('國家賠償法', 'I0020004', ['2']),
  ...lawEntries('家事事件法', 'B0010048', ['23', '100']),
  ...lawEntries('訴願法', 'A0030020', ['14']),
  ...lawEntries('勞工保險條例', 'N0050001', ['34', '54', '63', '63-1', '65', '65-1'], ['勞保條例']),
  ...lawEntries('全民健康保險法', 'L0060001', ['18', '27'], ['健保法']),
  ...lawEntries('公司法', 'J0080001', ['165']),
  ...lawEntries('道路交通安全規則', 'K0040013', ['16', '30']),
  ...lawEntries('信託法', 'I0020024', ['1']),
  ...lawEntries('納稅者權利保護法', 'G0340142', ['1', '7', '11']),
  // 勞動基準法 N0030001（law-registry SSOT 確認）
  '勞基法§11':  { pcode: 'N0030001', flno: '11', name: '勞動基準法' },
  '勞基法§14':  { pcode: 'N0030001', flno: '14', name: '勞動基準法' },
  '勞基法§16':  { pcode: 'N0030001', flno: '16', name: '勞動基準法' },
  '勞基法§17':  { pcode: 'N0030001', flno: '17', name: '勞動基準法' },
  '勞基法§19':  { pcode: 'N0030001', flno: '19', name: '勞動基準法' },
  '勞基法§20':  { pcode: 'N0030001', flno: '20', name: '勞動基準法' },
  '勞基法§24':  { pcode: 'N0030001', flno: '24', name: '勞動基準法' },
  '勞基法§32':  { pcode: 'N0030001', flno: '32', name: '勞動基準法' },
  '勞基法§36':  { pcode: 'N0030001', flno: '36', name: '勞動基準法' },
  '勞基法§38':  { pcode: 'N0030001', flno: '38', name: '勞動基準法' },
  '勞基法§59':  { pcode: 'N0030001', flno: '59', name: '勞動基準法' },
  '勞基法§79':  { pcode: 'N0030001', flno: '79', name: '勞動基準法' },
  // 勞工退休金條例 N0030020（非 N0030013，2026-06-13 修正）
  '勞退條例§12': { pcode: 'N0030020', flno: '12', name: '勞工退休金條例' },
  '勞退條例§14': { pcode: 'N0030020', flno: '14', name: '勞工退休金條例' },
  // 性別平等工作法 N0030014
  '性平法§15':  { pcode: 'N0030014', flno: '15', name: '性別平等工作法' },
  '性平法§16':  { pcode: 'N0030014', flno: '16', name: '性別平等工作法' },
  // 土地法 D0060001
  '土地法§97':  { pcode: 'D0060001', flno: '97', name: '土地法' },
  '土地法§99':  { pcode: 'D0060001', flno: '99', name: '土地法' },
  '土地法§100': { pcode: 'D0060001', flno: '100', name: '土地法' },
  // 租賃住宅市場發展及管理條例 D0060125
  '租賃專法§7': { pcode: 'D0060125', flno: '7', name: '租賃住宅市場發展及管理條例' },
  '租賃專法§10': { pcode: 'D0060125', flno: '10', name: '租賃住宅市場發展及管理條例' },
  '租賃專法§11': { pcode: 'D0060125', flno: '11', name: '租賃住宅市場發展及管理條例' },
  // 民法 B0000001
  '民法§425':  { pcode: 'B0000001', flno: '425', name: '民法' },
  '民法§429':  { pcode: 'B0000001', flno: '429', name: '民法' },
  '民法§430':  { pcode: 'B0000001', flno: '430', name: '民法' },
  '民法§431':  { pcode: 'B0000001', flno: '431', name: '民法' },
  '民法§432':  { pcode: 'B0000001', flno: '432', name: '民法' },
  '民法§1138': { pcode: 'B0000001', flno: '1138', name: '民法' },
  '民法§1144': { pcode: 'B0000001', flno: '1144', name: '民法' },
  '民法§1223': { pcode: 'B0000001', flno: '1223', name: '民法' },
  // 消費者保護法 J0170001（非 J0150003，2026-06-13 修正）
  '消保法§19':   { pcode: 'J0170001', flno: '19', name: '消費者保護法' },
  '消保法§51':   { pcode: 'J0170001', flno: '51', name: '消費者保護法' },
  '消保法§56-1': { pcode: 'J0170001', flno: '56-1', name: '消費者保護法' },
};

/**
 * 計算字串的 SHA-256 hash
 * @param {string} text
 * @returns {string} 64位十六進位 hash
 */
export function sha256(text) {
  return createHash('sha256').update(text, 'utf8').digest('hex');
}

/**
 * 從 law.moj.gov.tw 抓取單條法條全文（HTML 解析）
 *
 * law.moj 的 JSON API 路徑已不存在，改抓 LawSingle.aspx HTML
 * 並用 regex 提取 .law-article 內的條文文字。
 * 2026-06-13 驗証：N0030020§12、N0030001§17 均可正確取得。
 *
 * @param {string} pcode 法律 pcode
 * @param {string} flno 條號
 * @returns {Promise<{text: string, url: string}>}
 */
export async function fetchArticleFromMoj(pcode, flno) {
  const url = `https://law.moj.gov.tw/LawClass/LawSingle.aspx?pcode=${pcode}&flno=${flno}`;

  const resp = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (compatible; AVS-Verifier/1.0; +https://avs.choulegal.com)',
      'Accept': 'text/html,application/xhtml+xml',
      'Accept-Language': 'zh-TW,zh;q=0.9',
    },
  });

  if (!resp.ok) {
    throw new Error(`law.moj HTTP error: ${resp.status} for ${pcode}/${flno}`);
  }

  const html = await resp.text();

  // 從 .law-article div 內抓條文文字，去除 HTML 標籤
  const articleMatch = html.match(/<div class="law-article">([\s\S]*?)<\/div>\s*<\/div>/);
  if (!articleMatch) {
    throw new Error(`法條解析失敗（找不到 .law-article）：${pcode}/${flno}，頁面長度 ${html.length}`);
  }

  // 移除 HTML 標籤，保留文字
  const text = articleMatch[1]
    .replace(/<[^>]+>/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!text || text.length < 5) {
    throw new Error(`法條文字過短或空白：${pcode}/${flno}`);
  }

  return { text, url };
}

/**
 * 查詢法條：先查 cache，cache miss 再抓網路
 * @param {string} article 法條識別（如 "勞退條例§12"）
 * @param {object} [opts]
 * @param {boolean} [opts.forceRefresh=false] 強制重新抓取
 * @returns {Promise<{article: string, text: string, hash: string, source_url: string, fetched_at: string, from_cache: boolean}>}
 */
export async function lookupLaw(article, opts = {}) {
  const known = KNOWN_LAWS[article];
  if (!known) {
    return {
      article,
      text: null,
      hash: null,
      source_url: null,
      fetched_at: null,
      from_cache: false,
      error: `未知法條識別符 "${article}"，請在 KNOWN_LAWS 中新增 pcode 對照`,
    };
  }

  const cacheFile = join(CACHE_DIR, `${known.pcode}_${known.flno.replace('/', '-')}.json`);

  if (!opts.forceRefresh && existsSync(cacheFile)) {
    const cached = JSON.parse(readFileSync(cacheFile, 'utf8'));
    return { ...cached, from_cache: true };
  }

  if (opts.offline) {
    return {
      article,
      text: null,
      hash: null,
      source_url: null,
      fetched_at: null,
      from_cache: false,
      error: `離線模式找不到法條快取：${article}`,
    };
  }

  try {
    const { text, url } = await fetchArticleFromMoj(known.pcode, known.flno);
    const hash = sha256(text);
    const fetched_at = new Date().toISOString().slice(0, 10);

    const record = {
      article,
      law_name: known.name,
      pcode: known.pcode,
      flno: known.flno,
      text,
      hash,
      source_url: url,
      fetched_at,
    };

    if (!existsSync(CACHE_DIR)) mkdirSync(CACHE_DIR, { recursive: true });
    writeFileSync(cacheFile, JSON.stringify(record, null, 2), 'utf8');

    return { ...record, from_cache: false };
  } catch (err) {
    return {
      article,
      text: null,
      hash: null,
      source_url: null,
      fetched_at: null,
      from_cache: false,
      error: err.message,
    };
  }
}

/**
 * 批次更新所有已知法條的 cache
 * @param {object} [opts]
 * @param {boolean} [opts.forceRefresh=false]
 * @param {function} [opts.onProgress] callback(article, result)
 */
export async function updateAllLaws(opts = {}) {
  const results = [];
  for (const article of Object.keys(KNOWN_LAWS)) {
    const result = await lookupLaw(article, { forceRefresh: opts.forceRefresh ?? false });
    results.push(result);
    if (opts.onProgress) opts.onProgress(article, result);
    await new Promise(r => setTimeout(r, 200)); // 避免頻繁請求
  }
  return results;
}

export { KNOWN_LAWS };
